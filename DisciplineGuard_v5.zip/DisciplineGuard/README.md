# Discipline Guard v5.0 (com.me.discipline)

A phone discipline system: daily limit, sleep lock, prayer guard and a daily timetable, all enforced on the device.

## What is new in v5
- Whole app in English, with a clean premium dark design
- New animated lock screen (breathing glow ring, live countdown, state colours)
- Calls-only button on the lock screen. There is no emergency unlock and no way to get more screen time.

## Build
Push to GitHub > Actions > "Build APK" > Artifacts > `DisciplineGuard-apk`.

## Fixed rules (change them in `Config.kt` BEFORE you push; there is no setting in the app)
- 3 hours (180 min) a day nothing is blocked. After that the whole phone locks until midnight (calls only).
- 9:00 PM to 5:00 AM: sleep mode. Whole phone locked (calls only, WhatsApp included).
- After activation the guard cannot be switched off, limits cannot be changed, Settings is blocked, and (with Device Owner) uninstall needs a factory reset.
- No emergency unlock. The only way out is a phone factory reset.

## Modules
1. **Prayer Guard**: prayer-time lock, live photo proof, penalty for missed prayers (60 min, +30 for each further miss, all five = 24 hours).
2. **Daily Timetable**: daily tasks with a time slot, optional photo proof and a penalty. A missed task locks the phone, and each further miss that day adds 15 minutes.

## Setup (in this order)
1. Open the app and allow all permissions (Accessibility, Overlay, Device Admin, Battery, Notifications, Exact alarms, Location if Prayer Guard is on).
2. Check the prayer times and add your timetable tasks.
3. (Full protection) Make the app Device Owner once from a PC: remove all accounts from the phone, then run
   `adb shell dpm set-device-owner com.me.discipline/.AdminReceiver`
4. Tap "ACTIVATE (permanent)" on the dashboard and type LOCK.

## Notes
- Only calls (dialer, contacts, in-call) and the alarm clock stay usable while the phone is locked.
- Task proof photos are not verified by the app; the system relies on your honesty.
- Voice reminders are spoken in Urdu, Hindi or English, depending on which text-to-speech voice is installed.
