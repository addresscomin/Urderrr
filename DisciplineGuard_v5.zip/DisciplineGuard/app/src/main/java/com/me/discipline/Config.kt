package com.me.discipline

/**
 * FIXED RULES. Activate hone ke baad app me inhe badalne ka koi raasta nahi hai.
 * Badalna ho to GitHub par push karne se PEHLE yahin badlo.
 */
object Config {
    const val DAILY_LIMIT_MIN = 180            // total daily screen time (3 hours)
    const val SLEEP_START_MIN = 21 * 60        // raat 9:00 PM
    const val SLEEP_END_MIN = 5 * 60           // subah 5:00 AM
    const val SLEEP_LOCK_AFTER_MS = 10_000L    // sleep me lock screen 10 sec baad phone lock
    const val LOCKED_LOCK_AFTER_MS = 25_000L   // lock the phone 25 s after a limit/penalty screen
}
