package com.me.discipline

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Animated ring: soft breathing glow + a sweeping arc. Pure canvas, no assets. */
class RingView(c: Context) : View(c) {
    var accent: Int = Color.parseColor("#8B9BFF")
        set(v) { field = v; invalidate() }
    private var sweep = 0f
    private var pulse = 0f
    private val density = c.resources.displayMetrics.density
    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    private val spin = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 7000L; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { sweep = it.animatedValue as Float; invalidate() }
    }
    private val breathe = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2800L; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        addUpdateListener { pulse = it.animatedValue as Float }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); spin.start(); breathe.start() }
    override fun onDetachedFromWindow() { spin.cancel(); breathe.cancel(); super.onDetachedFromWindow() }

    private fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w < 10f || h < 10f) return
        val cx = w / 2f; val cy = h / 2f
        val r = minOf(w, h) / 2f - 22f * density
        val sw = 5f * density

        glow.shader = RadialGradient(
            cx, cy, r * 1.3f,
            intArrayOf(withA(accent, 0x30 + (pulse * 0x28).toInt()), withA(accent, 0)),
            floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r * 1.3f, glow)

        base.color = withA(accent, 0x2E); base.strokeWidth = sw
        cv.drawCircle(cx, cy, r, base)

        arc.color = accent; arc.strokeWidth = sw
        cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), sweep, 95f, false, arc)
        arc.color = withA(accent, 0x70); arc.strokeWidth = sw * 0.6f
        cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), sweep + 180f, 40f, false, arc)
    }
}

class BlockActivity : Activity() {
    companion object {
        @Volatile var visible = false
        fun show(c: Context, reason: String) {
            if (visible) return
            val i = Intent(c, BlockActivity::class.java).putExtra("reason", reason)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
            try { c.startActivity(i) } catch (e: Exception) {}
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var ring: RingView
    private lateinit var caption: TextView
    private lateinit var tTitle: TextView
    private lateinit var body: TextView
    private lateinit var timer: TextView
    private lateinit var btnDone: TextView
    private lateinit var btnSpeak: TextView
    private lateinit var btnTask: TextView
    private lateinit var btnHome: TextView
    private var cur: PrayerTimes.Prayer? = null
    private var curTask: Timetable.Task? = null

    private val ui = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT

        val d = Ui.dp(this, 1)
        val soft = Color.parseColor("#1E1E2A")

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#06060B"), Color.parseColor("#14102B"), Color.parseColor("#0B0B12"))
            )
            setPadding(28 * d, 56 * d, 28 * d, 40 * d)
            alpha = 0f
        }

        caption = Ui.text(this, "", 12f, Ui.SUB, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.25f }
        ring = RingView(this)
        timer = Ui.text(this, "", 34f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
        }
        val ringBox = FrameLayout(this).apply {
            addView(ring, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(timer, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        tTitle = Ui.text(this, "", 26f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        body = Ui.text(this, "", 15f, Color.parseColor("#B4B4C2")).apply { gravity = Gravity.CENTER; setLineSpacing(0f, 1.15f) }

        btnDone = Ui.pill(this, "Submit prayer proof (live photo)", Ui.BLUE, Color.WHITE) { onProof() }
        btnSpeak = Ui.pill(this, "Repeat voice reminder", soft, Color.WHITE) {
            val p = cur
            if (p != null) VoiceService.speak(this, "reminder", p.idx, ((p.deadline - System.currentTimeMillis()) / 60000L).coerceAtLeast(1))
        }
        btnTask = Ui.pill(this, "", soft, Ui.GREEN) {
            val t = curTask
            if (t != null) Timetable.confirm(this, t)
        }
        val btnPhone = Ui.pill(this, "Phone (calls only)", Ui.GREEN, Color.BLACK) {
            try { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
        btnHome = Ui.pill(this, "Back to Home", soft, Color.WHITE) { goHome() }

        root.addView(caption, Ui.lp(this, 0))
        root.addView(ringBox, LinearLayout.LayoutParams(250 * d, 250 * d).apply { topMargin = 14 * d; gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(tTitle, Ui.lp(this, 10))
        root.addView(body, Ui.lp(this, 10))
        for (v in listOf<View>(btnDone, btnSpeak, btnTask, btnPhone, btnHome)) root.addView(v, Ui.lp(this, 12))

        val sv = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false; setBackgroundColor(Color.parseColor("#06060B")); addView(root) }
        setContentView(sv)
        root.animate().alpha(1f).setDuration(700L).start()
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (i != null) setIntent(i) }
    override fun onResume() {
        super.onResume(); visible = true; h.post(ui)
        Hardening.enterLockTask(this)
    }
    override fun onPause() { visible = false; h.removeCallbacks(ui); super.onPause() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val extra = intent?.getStringExtra("reason") ?: "locked"
        val own = Policy.ownScreenReason(this)
        val pr = if (Prefs.armed(this)) PrayerTimes.active(this, now) else null
        cur = pr
        val r: String? = when {
            own != null -> own
            extra == "tamper" -> "tamper"
            else -> null
        }
        if (r == null || !Prefs.armed(this)) {
            if (!Prefs.armed(this)) { try { stopLockTask() } catch (e: Exception) {} }
            finish(); goHome(); return
        }

        val task = if (r != "tamper") Timetable.active(this, now).firstOrNull() else null
        curTask = task
        if (task != null) {
            btnTask.visibility = View.VISIBLE
            btnTask.text = "${task.title}: mark done" + (if (task.proof) " (photo)" else "")
        } else btnTask.visibility = View.GONE

        btnDone.visibility = if (r == "prayer") View.VISIBLE else View.GONE
        btnSpeak.visibility = if (r == "prayer") View.VISIBLE else View.GONE
        btnHome.visibility = if (r == "tamper") View.VISIBLE else View.GONE

        when (r) {
            "prayer" -> {
                val p = pr ?: return
                ring.accent = Color.parseColor("#4ADE9A")
                caption.text = "PRAYER TIME"
                tTitle.text = "${PrayerTimes.NAMES[p.idx]} prayer"
                val left = ((p.deadline - now) / 60000L).coerceAtLeast(0)
                body.text = "Your phone is locked. Pray first.\n$left min left before the deadline.\nAfterwards, submit a LIVE photo of your prayer mat. A tick alone is not accepted."
                timer.text = fmt(p.deadline - now)
                val wait = p.start + Policy.MIN_PRAYER_MS - now
                if (wait > 0) {
                    btnDone.alpha = 0.4f; btnDone.isEnabled = false
                    btnDone.text = "Proof opens in ${wait / 1000} s"
                } else {
                    btnDone.alpha = 1f; btnDone.isEnabled = true
                    btnDone.text = "Submit prayer proof (live photo)"
                }
            }
            "sleep" -> {
                ring.accent = Color.parseColor("#8B9BFF")
                caption.text = "SLEEP MODE"
                tTitle.text = "Time to rest"
                body.text = "Your phone is locked from ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} to ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)}.\nOnly calls will work."
                timer.text = fmt(SleepMode.endsAt(now) - now)
            }
            "locked" -> {
                ring.accent = Color.parseColor("#FF5C6C")
                caption.text = "PHONE LOCKED"
                val why = when (Prefs.lockReason(this)) {
                    "missed" -> "You missed a prayer, so the phone is fully locked."
                    "task" -> "You missed a routine task, so the phone is locked as a penalty."
                    else -> "Today's ${Config.DAILY_LIMIT_MIN / 60}-hour phone limit is finished."
                }
                tTitle.text = when (Prefs.lockReason(this)) {
                    "missed" -> "Prayer missed"
                    "task" -> "Task missed"
                    else -> "Limit reached"
                }
                body.text = why + "\nOnly calls will work."
                timer.text = fmt(Prefs.lockUntil(this) - now)
            }
            else -> {
                ring.accent = Color.parseColor("#FFB84D")
                caption.text = "PROTECTED"
                tTitle.text = "Settings are locked"
                body.text = "The guard is active. It can only be removed by a factory reset."
                timer.text = ""
            }
        }
    }

    private fun onProof() {
        val p = cur ?: return
        if (System.currentTimeMillis() < p.start + Policy.MIN_PRAYER_MS) return
        startActivity(Intent(this, ProofActivity::class.java))
    }

    private fun goHome() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {}
    }
}
