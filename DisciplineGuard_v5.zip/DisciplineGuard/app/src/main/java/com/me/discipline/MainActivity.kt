package com.me.discipline

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Dashboard + setup + Activate. Prayer Guard and Daily Timetable have their own screens. */
class MainActivity : Activity() {
    private lateinit var col: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (Prefs.armed(this@MainActivity) && Policy.ownScreenReason(this@MainActivity) != null) {
                BlockActivity.show(this@MainActivity, "locked")
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked")
            finish()
            return
        }
        Hardening.apply(this)
        render()
        h.post(tick)
    }

    override fun onPause() { h.removeCallbacks(tick); super.onPause() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun d(v: Int) = Ui.dp(this, v)

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun accOn(): Boolean {
        val flat = ComponentName(this, BlockerAccessibilityService::class.java).flattenToString()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(flat)
    }

    private fun isHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == packageName
    }

    private fun open(a: String, pkg: Boolean = true) {
        try {
            val i = Intent(a)
            if (pkg) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) { toast("Could not open that screen") }
    }

    private fun perm(parent: LinearLayout, name: String, ok: Boolean, action: () -> Unit) {
        Ui.row(this, parent, name, if (ok) "Allowed" else "Allow", if (ok) Ui.GREEN else Ui.BLUE) { if (!ok) action() }
    }

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(18), d(56), d(18), d(48)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG); isVerticalScrollBarEnabled = false }
        sv.addView(col)
        setContentView(sv)

        val armed = Prefs.armed(this)
        val owner = Hardening.isOwner(this)
        val namazOn = NamazPrefs.enabled(this)

        col.addView(Ui.text(this, "Discipline Guard", 32f, Ui.LABEL, true).apply { setPadding(d(4), 0, 0, 0) })
        col.addView(Ui.text(this, "Focus, prayer and routine, enforced.", 14f, Ui.SUB).apply { setPadding(d(4), d(2), 0, d(6)) })

        // ---- status ----
        Ui.section(this, col, "Status")
        val st = Ui.cardIn(this, col)
        Ui.row(this, st, "Guard", if (armed) "Active (permanent)" else "Off", if (armed) Ui.GREEN else Ui.RED)
        Ui.row(this, st, "Lifetime protection (Device Owner)", if (owner) "On" else "Off", if (owner) Ui.GREEN else Ui.RED)
        Ui.row(this, st, "Phone used today", "${Prefs.used(this) / 60000L} / ${Config.DAILY_LIMIT_MIN} min")
        Ui.row(this, st, "Sleep lock", "${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} - ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)}")

        // ---- modules ----
        Ui.section(this, col, "Modules")
        val mc = Ui.cardIn(this, col)
        Ui.row(this, mc, "Prayer Guard", (if (namazOn) "On" else "Off") + "  ›", Ui.BLUE) {
            startActivity(Intent(this, NamazActivity::class.java))
        }
        Ui.row(this, mc, "Daily Timetable", "${Timetable.all(this).size} tasks  ›", Ui.BLUE) {
            startActivity(Intent(this, TimetableActivity::class.java))
        }

        // ---- permissions ----
        Ui.section(this, col, "Permissions")
        val pc = Ui.cardIn(this, col)
        val pm = getSystemService(PowerManager::class.java)
        perm(pc, "Notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        perm(pc, "Exact alarms", Scheduler.canExact(this)) {
            if (Build.VERSION.SDK_INT >= 31) open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        }
        perm(pc, "Display over other apps", Settings.canDrawOverlays(this)) { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }
        perm(pc, "Accessibility (block engine)", accOn()) { open(Settings.ACTION_ACCESSIBILITY_SETTINGS, false) }
        perm(pc, "Device Admin (phone lock)", Policy.adminActive(this)) {
            try {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed to lock the phone"))
            } catch (e: Exception) { toast("Could not open the admin screen") }
        }
        perm(pc, "Battery optimization off", pm.isIgnoringBatteryOptimizations(packageName)) {
            open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        }
        if (namazOn) {
            perm(pc, "Location (accurate prayer times)", checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2)
            }
        }
        perm(pc, "Discipline Home as default launcher", isHome()) { open(Settings.ACTION_HOME_SETTINGS, false) }

        if (!owner) {
            pc.addView(Ui.text(this,
                "For full uninstall and disable protection, the app must be Device Owner (Android does not give this to normal apps). From a PC, once:\n\nadb shell dpm set-device-owner com.me.discipline/.AdminReceiver\n\nRemove all Google and other accounts from the phone first, run the command, then add the accounts back.",
                12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(6)); setTextIsSelectable(true) })
        }

        // ---- fixed rules ----
        Ui.section(this, col, "Fixed rules")
        val rc = Ui.cardIn(this, col)
        rc.addView(Ui.text(this,
            "• For ${Config.DAILY_LIMIT_MIN / 60} hours a day nothing is blocked. When the limit is reached, the whole phone locks until midnight (calls only).\n" +
                "• From ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} to ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)} sleep mode locks the whole phone (calls only, WhatsApp included).\n" +
                "• A missed timetable task locks the phone as a penalty.\n" +
                "• A missed prayer locks the phone as a penalty.",
            14f, Ui.LABEL).apply { setPadding(0, d(10), 0, d(10)); setLineSpacing(0f, 1.15f) })

        // ---- activate ----
        Ui.section(this, col, "Guard")
        val gc = Ui.cardIn(this, col)
        if (!armed) {
            gc.addView(Ui.pill(this, "ACTIVATE (permanent)", Ui.RED, Color.WHITE) { confirmActivate() }, Ui.lp(this, 6))
            gc.addView(Ui.text(this,
                "Set up all permissions, prayer times and your timetable first, then activate. After activation there is no off switch and the rules cannot be changed. There is no way out except a phone factory reset.",
                12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(10)) })
        } else {
            gc.addView(Ui.text(this,
                "The guard is permanently active and has no off switch." +
                    (if (owner) " Only a phone factory reset removes it." else " (Uninstall protection is weak because the app is not Device Owner.)"),
                14f, Ui.SUB).apply { setPadding(0, d(10), 0, d(10)) })

        }
    }

    private fun confirmActivate() {
        if (!accOn() || !Policy.adminActive(this)) {
            toast("Allow Accessibility and Device Admin first."); return
        }
        val et = EditText(this).apply { hint = "Type LOCK" }
        AlertDialog.Builder(this)
            .setTitle("Activate permanently")
            .setMessage("After activation:\n• The ${Config.DAILY_LIMIT_MIN / 60}-hour daily limit is fixed\n• The ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)}-${TimeUtil.fmtMin(Config.SLEEP_END_MIN)} sleep lock is fixed\n• Settings are blocked and the guard cannot be switched off\n• Only new timetable tasks can be added\n" +
                (if (Hardening.isOwner(this)) "• Uninstall only via factory reset\n" else "• Uninstall protection is weak (not Device Owner)\n") +
                "• There is no emergency unlock\n\nIf you are sure, type LOCK below.")
            .setView(et)
            .setPositiveButton("ACTIVATE") { _, _ ->
                if (et.text.toString().trim().uppercase() == "LOCK") {
                    Prefs.activate(this)
                    Hardening.apply(this)
                    Scheduler.rescheduleAll(this)
                    BlockerService.start(this)
                    render()
                } else toast("You did not type LOCK. Cancelled.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
