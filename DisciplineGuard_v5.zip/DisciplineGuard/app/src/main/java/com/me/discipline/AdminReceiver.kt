package com.me.discipline

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) { Hardening.apply(context) }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Disabling Discipline Guard breaks your promise to yourself. It can only be removed by a phone factory reset."
}
