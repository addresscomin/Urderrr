package com.me.discipline

import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var blockSince = 0L
    private var ticks = 0

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (e: Throwable) {}
            h.postDelayed(this, TICK)
        }
    }

    companion object {
        const val TICK = 5000L
        fun start(c: Context) {
            try { c.startForegroundService(Intent(c, BlockerService::class.java)) } catch (e: Exception) {}
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg("Guard is running")
        h.post(loop)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startFg("Guard is running")
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        start(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        super.onDestroy()
    }

    private fun startFg(text: String) {
        val n = Notif.build(this, "guard", "Discipline Guard", text)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun tick() {
        if (!Prefs.armed(this)) return
        val now = System.currentTimeMillis()
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val interactive = pm.isInteractive && !km.isKeyguardLocked
        val pkg = BlockerAccessibilityService.currentPkg

        // ---- punishments (namaz module + timetable module) ----
        Namaz.sweepMissed(this)
        Timetable.sweep(this)

        // ---- Device Owner hardening ----
        if (Hardening.isOwner(this)) {
            Hardening.statusBar(this, Policy.ownScreenReason(this) != null)
            Hardening.syncLockTask(this)
        }

        // ---- screen time counting: call / lock screen ka time nahi gina jata ----
        val free = pkg != null && Policy.alwaysAllowed(this).contains(pkg) && pkg != packageName
        if (interactive && !free && Policy.ownScreenReason(this) == null) {
            Prefs.addUsed(this, TICK)
        }

        // ---- daily limit (FIXED 3 ghante): poora hote hi raat 12 baje tak phone band ----
        if (Prefs.used(this) >= Config.DAILY_LIMIT_MIN * 60000L) {
            val eod = Policy.endOfDay()
            if (Prefs.lockUntil(this) < eod) {
                Prefs.extendLock(this, eod, "limit")
                VoiceService.speak(this, "limit", 0, 0)
            }
        }

        // ---- enforce ----
        val reason = Policy.ownScreenReason(this)
        if (interactive && pkg != null) {
            val r = Policy.block(this, pkg)
            if (r != null) BlockActivity.show(this, r)
        }
        if (reason != null && interactive && !BlockActivity.visible && pkg != null &&
            pkg != "com.android.systemui" && Prefs.long(this, "proofUntil") < now) {
            // band ke waqt screen par hamesha lock screen (home par bhi)
            if (!Policy.alwaysAllowed(this).contains(pkg) || pkg == packageName) BlockActivity.show(this, reason)
        }

        // ---- lock screen khuli rahe to phone ki screen band (sleep: 10 sec, baaki: 25 sec) ----
        if (BlockActivity.visible && interactive && (reason == "sleep" || reason == "locked")) {
            val after = if (reason == "sleep") Config.SLEEP_LOCK_AFTER_MS else Config.LOCKED_LOCK_AFTER_MS
            if (blockSince == 0L) blockSince = now
            else if (now - blockSince > after) {
                blockSince = 0L
                try {
                    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    if (dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))) dpm.lockNow()
                } catch (e: Exception) {}
            }
        } else blockSince = 0L

        // ---- notification text (har minute) ----
        ticks++
        if (ticks % 12 == 1) {
            val next = PrayerTimes.next(this, now)
            val t = if (next != null)
                "Next prayer: ${PrayerTimes.NAMES[next.idx]} ${SimpleDateFormat("hh:mm a", Locale.US).format(Date(next.start))}"
            else "Sleep ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} - ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)}"
            val usedMin = Prefs.used(this) / 60000L
            getSystemService(NotificationManager::class.java)
                .notify(1, Notif.build(this, "guard", "Discipline Guard  •  $usedMin/${Config.DAILY_LIMIT_MIN} min", t))
        }
    }
}
