package com.me.discipline

import android.content.Context

/** NAMAZ MODULE ka alag store ("namaz" SharedPreferences) — core aur timetable se bilkul alag. */
object NamazPrefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("namaz", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    private fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    private fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    private fun bool(c: Context, k: String): Boolean = sp(c).getBoolean(k, false)
    private fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }

    // module ON/OFF: sirf Activate se pehle badal sakte ho
    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, on: Boolean) {
        if (Prefs.armed(c)) return
        sp(c).edit().putBoolean("enabled", on).apply()
    }

    fun lat(c: Context): Double = str(c, "lat", "24.8607").toDoubleOrNull() ?: 24.8607
    fun lng(c: Context): Double = str(c, "lng", "67.0011").toDoubleOrNull() ?: 67.0011
    fun windowMin(c: Context): Int = int(c, "window", 90)
    fun setWindowMin(c: Context, v: Int) = setInt(c, "window", v)

    // saved (manual) namaz times: minutes-of-day x5
    fun manualTimes(c: Context): IntArray? {
        val s = str(c, "manual", "")
        if (s.isEmpty()) return null
        val p = s.split(",").mapNotNull { it.trim().toIntOrNull() }
        return if (p.size == 5) p.toIntArray() else null
    }
    fun setManualTimes(c: Context, a: IntArray) = setStr(c, "manual", a.joinToString(","))
    fun clearManualTimes(c: Context) = setStr(c, "manual", "")

    // namaz record
    fun done(c: Context, day: String, idx: Int) = bool(c, "done_${day}_$idx")
    fun setDone(c: Context, day: String, idx: Int) = setBool(c, "done_${day}_$idx", true)
    fun missed(c: Context, day: String, idx: Int) = bool(c, "miss_${day}_$idx")
    fun setMissed(c: Context, day: String, idx: Int) = setBool(c, "miss_${day}_$idx", true)
    fun bumpMissed(c: Context, day: String): Int {
        val n = int(c, "mc_$day", 0) + 1
        setInt(c, "mc_$day", n)
        return n
    }
    fun proofCount(c: Context): Int = int(c, "proofCount", 0)
    fun addProof(c: Context) = setInt(c, "proofCount", proofCount(c) + 1)
}
