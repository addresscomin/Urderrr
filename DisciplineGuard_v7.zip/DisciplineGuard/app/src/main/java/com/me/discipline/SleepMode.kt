package com.me.discipline

import java.util.Calendar

/** Raat 9 se subah 5: poora phone band (sirf call), lock screen. */
object SleepMode {
    fun active(now: Long = System.currentTimeMillis()): Boolean {
        val m = TimeUtil.minutesOfDay(now)
        val s = Config.SLEEP_START_MIN
        val e = Config.SLEEP_END_MIN
        return if (s > e) (m >= s || m < e) else (m in s until e)
    }

    /** Agli baar sleep kab khatam hoga (subah 5 baje). */
    fun endsAt(now: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, Config.SLEEP_END_MIN / 60)
        cal.set(Calendar.MINUTE, Config.SLEEP_END_MIN % 60)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
}
