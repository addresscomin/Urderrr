package com.me.discipline

import android.content.Context

/**
 * Claim-vs-record check. Works on recognised text only; nothing is stored.
 * A flag needs BOTH: a clear "I did it" claim AND a record that contradicts it.
 */
object VoiceCheck {
    private val PRAYER = listOf("नमाज", "नमाज़", "namaz", "namaaz", "salah", "salat", "prayer", "prayed", "نماز")
    private val DONE = listOf(
        "पढ ली", "पढ़ ली", "पढ लिया", "पढ़ लिया", "पढ चुका", "पढ़ चुका", "पढ चुकी", "पढ़ चुकी",
        "हो गई", "हो गयी", "हो गया", "कर ली", "कर लिया", "कर चुका", "कर चुकी",
        "padh li", "padh liya", "pad li", "pad liya", "ho gayi", "ho gai", "ho gaya", "kar li", "kar liya",
        "done", "finished", "completed", "i prayed", "have prayed", "already prayed", "offered",
        "پڑھ لی", "پڑھ لیا", "ہو گئی", "ہو گیا"
    )
    private val NEGATION = listOf(
        "नहीं", "नही", "nahi", "nahin", "not ", "n't", "बाकी", "baaki", "yet", "will ", "going to", "gonna",
        "पढूंगा", "पढूँगा", "पढूंगी", "padhunga", "padungi", "padunga", "karunga", "करूंगा", "करूँगा", "جاؤں گا", "نہیں"
    )

    private fun norm(s: String): String =
        s.lowercase().replace("\u093C", "").replace(Regex("\\s+"), " ").trim()

    /** Returns "prayer", "task" or null. */
    fun check(c: Context, texts: List<String>, now: Long = System.currentTimeMillis()): String? {
        if (!Prefs.armed(c)) return null
        for (raw in texts) {
            val t = norm(raw)
            if (t.length < 4) continue
            if (NEGATION.any { t.contains(norm(it)) }) continue
            if (DONE.none { t.contains(norm(it)) }) continue
            if (PRAYER.any { t.contains(norm(it)) } && PrayerTimes.active(c, now) != null) return "prayer"
            for (task in Timetable.active(c, now)) {
                val title = task.title.lowercase().trim()
                if (title.length >= 3 && t.contains(title)) return "task"
            }
        }
        return null
    }
}
