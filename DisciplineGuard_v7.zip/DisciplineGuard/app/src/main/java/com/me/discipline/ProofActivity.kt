package com.me.discipline

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

/**
 * Saboot: tick nahi chalega, camera se LIVE photo leni hoti hai.
 * Namaz ke liye (extra nahi) ya timetable task ke liye (extra "taskId").
 * Blank/andhera photo reject; photo app me save hoti hai (filesDir/proofs).
 */
class ProofActivity : Activity() {
    private var task: Timetable.Task? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val tid = intent?.getStringExtra("taskId")
        if (tid != null) {
            val t = Timetable.find(this, tid)
            if (t == null || !Timetable.isOpen(t, System.currentTimeMillis())) { finish(); return }
            task = t
        } else {
            val p = PrayerTimes.active(this)
            if (p == null || System.currentTimeMillis() < p.start + Policy.MIN_PRAYER_MS) { finish(); return }
        }
        Prefs.setLong(this, "proofUntil", System.currentTimeMillis() + 4 * 60000L)
        Hardening.syncLockTask(this)
        try {
            startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 77)
        } catch (e: Exception) {
            Prefs.setLong(this, "proofUntil", 0L)
            Toast.makeText(this, "Could not open the camera", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        Prefs.setLong(this, "proofUntil", 0L)
        val t = task
        if (t != null) { finishTask(t, res, data); return }

        val p = PrayerTimes.active(this)
        if (res != RESULT_OK || p == null) { toast("No proof received. Prayer not confirmed."); finish(); return }
        val bmp = data?.extras?.get("data") as? Bitmap
        if (bmp != null && !looksReal(bmp)) { toast("The photo is blank or too dark. Take a clear photo of your prayer mat."); finish(); return }
        save(bmp, "${p.day}_${p.idx}.jpg")
        NamazPrefs.setDone(this, p.day, p.idx)
        NamazPrefs.addProof(this)
        VoiceService.stop(this)
        VoiceService.speak(this, "done", p.idx, 0)
        finish()
    }

    private fun finishTask(t: Timetable.Task, res: Int, data: Intent?) {
        if (res != RESULT_OK) { toast("No proof received. Task not marked done."); finish(); return }
        if (!Timetable.isOpen(t, System.currentTimeMillis())) { toast("The task time has passed."); finish(); return }
        val bmp = data?.extras?.get("data") as? Bitmap
        if (bmp != null && !looksReal(bmp)) { toast("The photo is blank or too dark. Take a clear photo."); finish(); return }
        val day = Prefs.dayKey()
        save(bmp, "task_${day}_${t.id}.jpg")
        Timetable.setDone(this, day, t.id)
        toast("${t.title} done ✅")
        finish()
    }

    private fun save(bmp: Bitmap?, name: String) {
        try {
            if (bmp != null) {
                val dir = File(filesDir, "proofs"); dir.mkdirs()
                FileOutputStream(File(dir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            }
        } catch (e: Exception) {}
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    /** Dhakka hua lens / poora kaala / poora ek rang = reject. */
    private fun looksReal(b: Bitmap): Boolean {
        return try {
            val s = Bitmap.createScaledBitmap(b, 16, 16, true)
            var sum = 0.0; var sq = 0.0
            for (x in 0 until 16) for (y in 0 until 16) {
                val px = s.getPixel(x, y)
                val l = 0.299 * ((px shr 16) and 255) + 0.587 * ((px shr 8) and 255) + 0.114 * (px and 255)
                sum += l; sq += l * l
            }
            val mean = sum / 256.0
            sqrt(sq / 256.0 - mean * mean) > 10.0 && mean > 15.0
        } catch (e: Exception) { true }
    }
}
