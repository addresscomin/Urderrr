package com.me.discipline

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

object Scheduler {
    private val REMINDERS = intArrayOf(5, 10, 20, 30, 45, 60)

    fun canExact(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() else true

    /** Activate ke baad: namaz + sleep + timetable ke saare alarm. */
    fun rescheduleAll(c: Context) {
        if (!Prefs.armed(c)) return
        val now = System.currentTimeMillis()

        // --- namaz module ---
        if (NamazPrefs.enabled(c)) {
            for (off in -1..1) {
                for (p in PrayerTimes.day(c, off).prayers) {
                    prayer(c, p, 0, p.start, now)
                    REMINDERS.forEachIndexed { i, m ->
                        val t = p.start + m * 60000L
                        if (t < p.deadline - 60000L) prayer(c, p, i + 1, t, now)
                    }
                    prayer(c, p, 7, p.deadline, now)
                }
            }
        }

        // --- sleep (9PM / 5AM) ---
        for (off in 0..1) {
            val base = TimeUtil.midnight(off)
            val s = base + Config.SLEEP_START_MIN * 60000L
            val e = base + Config.SLEEP_END_MIN * 60000L
            alarm(c, s, now, "SLEEP", "sleep://$s") {}
            alarm(c, e, now, "SLEEP", "sleep://$e") {}
        }

        // --- timetable ---
        for (t in Timetable.all(c)) {
            for (off in 0..1) {
                val base = TimeUtil.midnight(off)
                val st = base + t.start * 60000L
                val en = base + t.end * 60000L
                alarm(c, st, now, "TASK", "task://${t.id}/$st") { it.putExtra("id", t.id).putExtra("kind", 0) }
                alarm(c, en + 1000L, now, "TASK", "task://${t.id}/$en") { it.putExtra("id", t.id).putExtra("kind", 1) }
            }
        }
        watchdog(c)
    }

    private fun prayer(c: Context, p: PrayerTimes.Prayer, kind: Int, at: Long, now: Long) {
        alarm(c, at, now, "PRAYER", "pray://${p.day}/${p.idx}/$kind") {
            it.putExtra("idx", p.idx).putExtra("day", p.day).putExtra("kind", kind)
                .putExtra("start", p.start).putExtra("deadline", p.deadline)
        }
    }

    private fun alarm(c: Context, at: Long, now: Long, action: String, data: String, fill: (Intent) -> Unit) {
        if (at <= now) return
        val i = Intent(c, AlarmReceiver::class.java).setAction(action).setData(Uri.parse(data))
        fill(i)
        val pi = PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        schedule(c, at, pi)
    }

    private fun watchdog(c: Context) {
        val i = Intent(c, AlarmReceiver::class.java).setAction("WATCHDOG")
        val pi = PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        schedule(c, System.currentTimeMillis() + 15 * 60000L, pi)
    }

    private fun schedule(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(AlarmManager::class.java)
        try {
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
