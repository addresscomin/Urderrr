package com.me.discipline

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Core store ("guard"): activation, daily usage and lock. Prayer has its own store (NamazPrefs), timetable has Timetable. */
object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun long(c: Context, k: String, d: Long = 0L): Long = sp(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }

    fun dayKey(ms: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    // ---- activation (one-way: wapas OFF ka koi function hi nahi hai) ----
    fun armed(c: Context) = bool(c, "armed")
    fun strict(c: Context) = bool(c, "strict")
    fun armedAt(c: Context) = long(c, "armedAt")
    fun activate(c: Context) {
        if (armed(c)) return
        setBool(c, "armed", true)
        setBool(c, "strict", true)
        setLong(c, "armedAt", System.currentTimeMillis())
    }

    // ---- lock (limit / missed prayer / missed task penalty) ----
    fun lockUntil(c: Context) = long(c, "lockUntil")
    fun lockReason(c: Context) = str(c, "lockReason", "locked")
    fun setLock(c: Context, until: Long, reason: String) {
        setLong(c, "lockUntil", until)
        setStr(c, "lockReason", reason)
    }
    /** Lock sirf badhta hai, kabhi chhota nahi hota. */
    fun extendLock(c: Context, until: Long, reason: String) {
        if (until > lockUntil(c)) setLock(c, until, reason)
    }

    // ---- daily usage ----
    private fun roll(c: Context) {
        val d = dayKey()
        if (str(c, "usedDay") != d) {
            setStr(c, "usedDay", d)
            setLong(c, "used", 0L)
        }
    }
    fun used(c: Context): Long { roll(c); return long(c, "used") }
    fun addUsed(c: Context, ms: Long) { roll(c); setLong(c, "used", long(c, "used") + ms) }
}
