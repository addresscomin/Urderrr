package com.me.discipline

import android.app.Activity
import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.UserManager

/**
 * Asli "permanent" protection. Ye sirf tab kaam karti hai jab app DEVICE OWNER ho:
 *   adb shell dpm set-device-owner com.me.focusguard/com.me.discipline.AdminReceiver
 * Device Owner ke bina Android kisi normal app ko uninstall-proof nahi banane deta.
 */
object Hardening {
    private var lastPkgs: Set<String> = emptySet()
    private var lastBar: Boolean? = null
    private var lastFree: Boolean? = null

    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    private fun dpm(c: Context) = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun isOwner(c: Context): Boolean = try { dpm(c).isDeviceOwnerApp(c.packageName) } catch (e: Exception) { false }

    private val RESTRICTIONS = listOf(
        UserManager.DISALLOW_SAFE_BOOT,          // safe mode se bypass band
        UserManager.DISALLOW_APPS_CONTROL,       // force stop / clear data / disable / uninstall (Settings se)
        UserManager.DISALLOW_CONFIG_DATE_TIME,   // time badal kar namaz chakma na de sake
        UserManager.DISALLOW_ADD_USER            // dusra user/guest bana kar bypass band
    )

    /** Strict ke hisaab se sab policies lagao / hatao. Phone reset hone par ye apne aap khatam. */
    fun apply(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c); val a = admin(c)
        val strict = Prefs.strict(c)
        try { d.setUninstallBlocked(a, c.packageName, strict) } catch (e: Exception) {}
        for (r in RESTRICTIONS) {
            try { if (strict) d.addUserRestriction(a, r) else d.clearUserRestriction(a, r) } catch (e: Exception) {}
        }
        if (strict) {
            try {
                val f = IntentFilter(Intent.ACTION_MAIN)
                f.addCategory(Intent.CATEGORY_HOME); f.addCategory(Intent.CATEGORY_DEFAULT)
                d.addPersistentPreferredActivity(a, f, ComponentName(c, HomeActivity::class.java))
            } catch (e: Exception) {}
            val perms = listOf(
                android.Manifest.permission.POST_NOTIFICATIONS,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.RECORD_AUDIO
            )
            for (p in perms) {
                try { d.setPermissionGrantState(a, c.packageName, p, DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED) } catch (e: Exception) {}
            }
        } else {
            try { d.clearPackagePersistentPreferredActivities(a, c.packageName) } catch (e: Exception) {}
            statusBar(c, false)
        }
    }

    /** Lock/namaz ke waqt status bar + control center band. */
    fun statusBar(c: Context, disable: Boolean) {
        if (!isOwner(c) || lastBar == disable) return
        try { dpm(c).setStatusBarDisabled(admin(c), disable); lastBar = disable } catch (e: Exception) {}
    }

    /** Jo apps abhi khul sakte hain (Policy.block == null) ki list. */
    fun allowedPackages(c: Context): Set<String> {
        val s = HashSet<String>(Policy.alwaysAllowed(c))
        s.add(c.packageName)
        try {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in c.packageManager.queryIntentActivities(q, 0)) {
                val p = ri.activityInfo.packageName
                if (Policy.block(c, p) == null) s.add(p)
            }
        } catch (e: Exception) {}
        return s
    }

    /** Lock-task whitelist: jo app block hai wo system level par hi start nahi hota (search/split-screen/recents sab se). */
    fun syncLockTask(c: Context) {
        if (!isOwner(c) || !Prefs.armed(c) || !Prefs.strict(c)) return
        try {
            val d = dpm(c); val a = admin(c)
            val pk = allowedPackages(c)
            if (pk != lastPkgs) { d.setLockTaskPackages(a, pk.toTypedArray()); lastPkgs = pk }
            val free = Policy.ownScreenReason(c) == null
            if (Build.VERSION.SDK_INT >= 28 && lastFree != free) {
                var f = DevicePolicyManager.LOCK_TASK_FEATURE_SYSTEM_INFO or DevicePolicyManager.LOCK_TASK_FEATURE_HOME
                if (free) f = f or DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS or DevicePolicyManager.LOCK_TASK_FEATURE_OVERVIEW
                d.setLockTaskFeatures(a, f)
                lastFree = free
            }
        } catch (e: Exception) {}
    }

    fun enterLockTask(a: Activity) {
        if (!isOwner(a) || !Prefs.armed(a) || !Prefs.strict(a)) return
        try {
            syncLockTask(a)
            val am = a.getSystemService(ActivityManager::class.java)
            if (am.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) a.startLockTask()
        } catch (e: Exception) {}
    }
}
