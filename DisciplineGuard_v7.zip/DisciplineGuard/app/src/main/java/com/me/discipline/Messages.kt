package com.me.discipline

/** Voice lines. Urdu / Hindi / English — jo TTS voice phone me ho. */
object Messages {
    private val ur = arrayOf("فجر", "ظہر", "عصر", "مغرب", "عشاء")
    private val hi = arrayOf("फ़ज्र", "ज़ुहर", "अस्र", "मग़रिब", "इशा")
    private val en = arrayOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha")

    private fun lie(lang: String, kind: String, arg: Long): String = when (lang) {
        "ur" -> if (kind == "lie_warn") "خبردار۔ آپ نے جو کہا وہ آپ کے ریکارڈ سے میل نہیں کھاتا۔ اپنے آپ سے جھوٹ مت بولیں۔ اگلی بار سزا ملے گی۔"
                else "جھوٹ پکڑا گیا۔ آپ کی بات ریکارڈ سے میل نہیں کھاتی۔ فون لاک میں ${arg} منٹ بڑھا دیے گئے ہیں۔"
        "hi" -> if (kind == "lie_warn") "चेतावनी। आपने जो कहा वो आपके रिकॉर्ड से मेल नहीं खाता। खुद से झूठ मत बोलिए। अगली बार सज़ा मिलेगी।"
                else "झूठ पकड़ा गया। आपकी बात रिकॉर्ड से मेल नहीं खाती। फ़ोन लॉक में ${arg} मिनट जोड़ दिए गए हैं।"
        else -> if (kind == "lie_warn") "Warning. What you just said does not match your record. Do not lie to yourself. The next one is a penalty."
                else "Lie detected. What you said does not match your record. ${arg} minutes added to the phone lock."
    }

    fun text(lang: String, kind: String, idx: Int, arg: Long): String {
        if (kind == "lie_warn" || kind == "lie_penalty") return lie(lang, kind, arg)
        return base(lang, kind, idx, arg)
    }

    private fun base(lang: String, kind: String, idx: Int, arg: Long): String = when (lang) {
        "ur" -> {
            val n = ur[idx]
            when (kind) {
                "adhan" -> if (idx == 0)
                    "فجر کی نماز کا وقت ہو گیا ہے۔ اٹھ جائیں، وضو کریں اور نماز پڑھیں۔ نماز نیند سے بہتر ہے۔"
                else "${n} کی نماز کا وقت ہو گیا ہے۔ فون رکھیں، وضو کریں اور نماز پڑھیں۔"
                "reminder" -> "${n} کی نماز ابھی تک نہیں پڑھی۔ صرف ${arg} منٹ باقی ہیں۔ فوراً نماز پڑھیں۔"
                "missed" -> "آپ نے ${n} کی نماز قضا کر دی ہے۔ سزا کے طور پر فون ${arg} منٹ کے لیے بند رہے گا۔"
                "done" -> "ماشاء اللہ، ${n} کی نماز پڑھ لی۔ فون کھول دیا گیا ہے۔"
                "task" -> "آپ نے اپنا روٹین پورا نہیں کیا۔ سزا کے طور پر فون ${arg} منٹ کے لیے بند رہے گا۔"
                "sleep" -> "سونے کا وقت ہو گیا ہے۔ فون اب صبح تک بند رہے گا۔ شب بخیر۔"
                else -> "آج کی تین گھنٹے کی فون کی حد پوری ہو گئی ہے۔ اب فون بند رہے گا۔ آرام کریں۔"
            }
        }
        "hi" -> {
            val n = hi[idx]
            when (kind) {
                "adhan" -> if (idx == 0)
                    "फ़ज्र की नमाज़ का वक़्त हो गया है। उठ जाइए, वुज़ू कीजिए और नमाज़ पढ़िए। नमाज़ नींद से बेहतर है।"
                else "${n} की नमाज़ का वक़्त हो गया है। फ़ोन रखिए, वुज़ू कीजिए और नमाज़ पढ़िए।"
                "reminder" -> "${n} की नमाज़ अभी तक नहीं पढ़ी। सिर्फ़ ${arg} मिनट बाक़ी हैं। फ़ौरन नमाज़ पढ़िए।"
                "missed" -> "आपने ${n} की नमाज़ क़ज़ा कर दी। सज़ा के तौर पर फ़ोन ${arg} मिनट के लिए बंद रहेगा।"
                "done" -> "माशा अल्लाह, ${n} की नमाज़ पढ़ ली। फ़ोन खोल दिया गया है।"
                "task" -> "आपने अपना रूटीन पूरा नहीं किया। सज़ा के तौर पर फ़ोन ${arg} मिनट के लिए बंद रहेगा।"
                "sleep" -> "सोने का वक़्त हो गया है। फ़ोन अब सुबह तक बंद रहेगा। शब बख़ैर।"
                else -> "आज की तीन घंटे की फ़ोन की हद पूरी हो गई है। अब फ़ोन बंद रहेगा। आराम कीजिए।"
            }
        }
        else -> {
            val n = en[idx]
            when (kind) {
                "adhan" -> if (idx == 0)
                    "It is time for Fajr prayer. Wake up, make wudu and pray. Prayer is better than sleep."
                else "It is time for ${n} prayer. Put the phone down, make wudu and pray."
                "reminder" -> "You have not prayed ${n} yet. Only ${arg} minutes left. Pray now."
                "missed" -> "You missed ${n} prayer. The phone will stay locked for ${arg} minutes."
                "done" -> "Mashallah. ${n} prayer done. Phone unlocked."
                "task" -> "You did not complete your routine. The phone will stay locked for ${arg} minutes as punishment."
                "sleep" -> "It is sleep time. The phone is locked until morning. Good night."
                else -> "Today's three hour phone limit is finished. The phone will stay locked."
            }
        }
    }
}
