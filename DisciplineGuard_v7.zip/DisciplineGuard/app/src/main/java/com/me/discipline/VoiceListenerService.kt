package com.me.discipline

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Voice Guard: listens on the device in a loop, compares claims with your record.
 * Audio and text are never saved or sent by this app; only a flag counter is kept.
 */
class VoiceListenerService : Service() {
    companion object {
        @Volatile var listening = false
        @Volatile private var alive = false

        fun start(c: Context) {
            if (alive) return
            if (!Prefs.armed(c) || !Prefs.bool(c, "voice", true)) return
            if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            try { c.startForegroundService(Intent(c, VoiceListenerService::class.java)) } catch (e: Exception) {}
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var lastFlag = 0L
    private var errors = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        try {
            val n = Notif.build(this, "listen", "Voice Guard", "Listening on this device. Audio is not saved.")
            if (Build.VERSION.SDK_INT >= 30) startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(4, n)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        if (!alive) { alive = true; h.post { listen() } }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false; listening = false
        h.removeCallbacksAndMessages(null)
        destroyRec()
        super.onDestroy()
    }

    private fun destroyRec() {
        try { rec?.cancel() } catch (e: Exception) {}
        try { rec?.destroy() } catch (e: Exception) {}
        rec = null
    }

    private fun later(ms: Long) { h.postDelayed({ listen() }, ms) }

    private fun listen() {
        if (!alive) return
        if (!Prefs.armed(this) || !Prefs.bool(this, "voice", true)) { stopSelf(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { stopSelf(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { listening = false; later(30_000L); return }
        destroyRec()
        val r = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        else SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) {
                listening = false
                when (e) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stopSelf(); return }
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> { errors = 0; later(400L) }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> later(2_000L)
                    else -> { errors++; later((3_000L * errors).coerceAtMost(30_000L)) }
                }
            }
            override fun onResults(res: Bundle?) {
                errors = 0
                val list = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (list != null) handle(list)
                later(300L)
            }
        })
        rec = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Config.VOICE_LANG)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { r.startListening(i) } catch (e: Exception) { later(3_000L) }
    }

    private fun handle(texts: List<String>) {
        val now = System.currentTimeMillis()
        if (now - VoiceService.lastSpeakAt < 25_000L) return   // do not react to the app's own voice
        if (now - lastFlag < 90_000L) return
        val kind = VoiceCheck.check(this, texts, now) ?: return
        lastFlag = now
        val key = "lie_" + Prefs.dayKey(now)
        val n = Prefs.int(this, key, 0) + 1
        Prefs.setInt(this, key, n)
        Prefs.setInt(this, "lieTotal", Prefs.int(this, "lieTotal", 0) + 1)
        val what = if (kind == "prayer") "a prayer" else "a task"
        if (n <= Config.VOICE_FREE_WARNINGS) {
            VoiceService.speak(this, "lie_warn", 0, 0)
            Notif.alert(this, 4001, "Voice Guard warning", "You said $what was done, but your record says it is not. Next time is a penalty.")
        } else {
            val pen = Config.VOICE_PENALTY_MIN * (n - Config.VOICE_FREE_WARNINGS)
            Prefs.extendLock(this, now + pen * 60_000L, "lie")
            VoiceService.speak(this, "lie_penalty", 0, pen.toLong())
            Notif.alert(this, 4001, "Lie detected", "You said $what was done, but your record says it is not. Phone locked for $pen min.")
            BlockActivity.show(this, "locked")
        }
    }
}
