# Focus Guard v6.1 (com.me.focusguard)

A phone discipline system: daily limit, sleep lock, prayer guard and a daily timetable, all enforced on the device.

## What is new in v6
- **Voice Guard**: listens on the device (foreground service, microphone icon and notification are always visible). If you say a prayer or a task is done while your record says it is not, you get a spoken warning (1 per day), then lock penalties of 30 min that grow with each further lie that day.
- Nothing is recorded: no audio and no text is saved by the app, only a counter of flags.
- Language for listening is `Config.VOICE_LANG` (default `hi-IN`, which also catches Hinglish).

## What came in v5
- Whole app in English, with a clean premium dark design
- New animated lock screen (breathing glow ring, live countdown, state colours)
- Calls-only button on the lock screen. There is no emergency unlock and no way to get more screen time.

## Build
Push to GitHub > Actions > "Build APK" > Artifacts > `DisciplineGuard-apk`.

## Fixed rules (change them in `Config.kt` BEFORE you push; there is no setting in the app)
- 3 hours (180 min) a day nothing is blocked. After that the whole phone locks until midnight (calls only).
- 9:00 PM to 5:00 AM: sleep mode. Whole phone locked (calls only, WhatsApp included).
- After activation the guard cannot be switched off, limits cannot be changed, Settings is blocked, and (with Device Owner) uninstall needs a factory reset.
- No emergency unlock. The only way out is a phone factory reset.

## Modules
1. **Prayer Guard**: prayer-time lock, live photo proof, penalty for missed prayers (60 min, +30 for each further miss, all five = 24 hours).
2. **Daily Timetable**: daily tasks with a time slot, optional photo proof and a penalty. A missed task locks the phone, and each further miss that day adds 15 minutes.

## Setup (in this order)
1. Open the app and allow all permissions (Accessibility, Overlay, Device Admin, Battery, Notifications, Exact alarms, Location if Prayer Guard is on).
2. Check the prayer times and add your timetable tasks.
3. (Full protection) Make the app Device Owner once from a PC: remove all accounts from the phone, then run
   `adb shell dpm set-device-owner com.me.focusguard/com.me.discipline.AdminReceiver`
4. Tap "ACTIVATE (permanent)" on the dashboard and type LOCK.

## Notes
- Only calls (dialer, contacts, in-call) and the alarm clock stay usable while the phone is locked.
- Task proof photos are not verified by the app; the system relies on your honesty.
- Voice reminders are spoken in Urdu, Hindi or English, depending on which text-to-speech voice is installed.

## Voice Guard notes
- Allow the Microphone permission in the app. For a fully offline recognizer, install the offline Hindi/English speech pack in your Google app settings. Without it, Android may send speech to Google for recognition.
- It only flags clear claims ("namaz padh li", "task done") that contradict the record. Anything with "not", "nahi", "will" is ignored. It cannot detect lies in general.
- On Android 14 and above the service can only be started while the app is open (Home screen counts), so open the app once after every reboot.
- Some phones stop background microphone use to save battery; keep battery optimization off for this app.
- Recognizer beeps and short gaps between listening cycles can happen on some phones.

## Updating
All builds are signed with the fixed key `app/fixed-debug.keystore`, so a new APK installs over the old one as an update (data kept). The app id is `com.me.focusguard`, so it installs next to the older `com.me.discipline` app.
