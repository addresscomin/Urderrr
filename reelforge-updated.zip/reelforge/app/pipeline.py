import subprocess, json
from pathlib import Path
from .download import download
from .transcribe import transcribe
from .highlights import pick_highlights
from .render import render_clip
from .captions import retext

def duration_of(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                       capture_output=True, text=True, check=True)
    return float(r.stdout.strip())

def _in(words, a, b): return [w for w in words if w["start"] >= a - .01 and w["end"] <= b + .01]

def run(job_dir: Path, url=None, file=None, layout="blur", style="hype", limit=10, progress=lambda s: None):
    job_dir.mkdir(parents=True, exist_ok=True)
    progress("Downloading video")
    src = Path(file) if file else download(url, job_dir)
    dur = duration_of(src)
    progress("Transcribing (captions)")
    words = transcribe(src)
    (job_dir / "words.json").write_text(json.dumps(words))
    progress("AI best moments dhoondh raha hai")
    clips = pick_highlights(src, words, dur)[:limit]
    res = []
    for i, c in enumerate(clips):
        progress(f"Rendering reel {i+1}/{len(clips)}")
        render_clip(src, words, c, job_dir, i, layout, style)
        res.append({"i": i, "file": f"reel_{i}.mp4", "title": c.get("title", f"Clip {i+1}"), "score": c.get("score", 0),
                    "start": c["start"], "end": c["end"], "layout": layout, "style": style, "v": 0,
                    "text": " ".join(w["w"] for w in _in(words, c["start"], c["end"]))})
    return res

def render_one(job_dir: Path, clip, text, style, start, end):
    uploads = sorted(job_dir.glob("upload.*"))
    src = uploads[0] if uploads else job_dir / "source.mp4"
    words = json.loads((job_dir / "words.json").read_text())
    ws = _in(words, start, end)
    if text.strip() != clip.get("text", "").strip() or not ws: ws = retext(ws, text, start, end)
    c = {**clip, "start": start, "end": end}
    render_clip(src, ws, c, job_dir, clip["i"], clip.get("layout", "blur"), style)
    return {**c, "style": style, "text": " ".join(w["w"] for w in ws)}
