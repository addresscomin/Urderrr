from faster_whisper import WhisperModel
from . import config
_model = None

def transcribe(path):
    """Returns list of words: {w, start, end}"""
    global _model
    if _model is None:
        _model = WhisperModel(config.WHISPER_MODEL, compute_type="int8")
    segs, _ = _model.transcribe(str(path), word_timestamps=True, vad_filter=True)
    words = []
    for s in segs:
        for w in (s.words or []):
            words.append({"w": w.word.strip(), "start": w.start, "end": w.end})
    return words
