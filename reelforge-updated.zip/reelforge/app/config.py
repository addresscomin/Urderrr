import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
DATA = Path(os.getenv("DATA_DIR", "data")); DATA.mkdir(exist_ok=True)
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "small")
CLIP_MIN = int(os.getenv("CLIP_MIN", 20))
CLIP_MAX = int(os.getenv("CLIP_MAX", 50))
MAX_CLIPS = int(os.getenv("MAX_CLIPS", 10))
FREE_CREDITS = int(os.getenv("FREE_CREDITS", 20))
WORKERS = int(os.getenv("WORKERS", 1))
