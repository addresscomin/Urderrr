import subprocess
from pathlib import Path
from .captions import make_ass

def render_clip(src: Path, words, clip, out_dir: Path, idx: int, layout="blur", style="hype"):
    ass = out_dir / f"c{idx}.ass"
    make_ass(words, clip["start"], clip["end"], ass, style)
    if layout == "crop":
        vf = "scale=-2:1920,crop=1080:1920"
    else:  # blur background + centered gameplay (best for 16:9 gaming)
        vf = ("split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,"
              "crop=1080:1920,boxblur=30:5[bg];[b]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2")
    vf += f",ass={ass.name}"
    out = out_dir / f"reel_{idx}.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(clip["start"]), "-t",
                    str(clip["end"] - clip["start"]), "-i", str(src.resolve()), "-vf", vf,
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-threads", "2", "-c:a", "aac", "-b:a", "160k",
                    "-movflags", "+faststart", out.name], cwd=out_dir, check=True)
    return out
