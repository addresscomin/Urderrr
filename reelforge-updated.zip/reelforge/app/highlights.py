import json, subprocess
import numpy as np
from . import config

def audio_energy(path):
    """RMS loudness per second (gaming hype = loud moments)."""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", "8000",
                          "-f", "s16le", "-"], capture_output=True, check=True).stdout
    a = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
    n = len(a) // 8000
    if n == 0: return np.zeros(1)
    return np.sqrt((a[:n*8000].reshape(n, 8000) ** 2).mean(axis=1))

def energy_candidates(path, duration):
    e = audio_energy(path)
    win = config.CLIP_MAX
    scores = np.convolve(e, np.ones(win) / win, mode="valid") if len(e) > win else e
    picks, taken = [], np.zeros(len(e) + 2 * win, bool)
    for i in np.argsort(scores)[::-1]:
        if taken[max(0, i - win): i + win].any(): continue
        taken[i:i + win] = True
        picks.append({"start": float(i), "end": float(min(i + win, duration)),
                      "title": f"Moment {len(picks)+1}", "score": float(scores[i])})
        if len(picks) >= config.MAX_CLIPS: break
    return sorted(picks, key=lambda x: x["start"])

def llm_pick(words, duration):
    from .llm import ask
    lines, cur, t0 = [], [], 0
    for w in words:
        if not cur: t0 = w["start"]
        cur.append(w["w"])
        if w["end"] - t0 > 6:
            lines.append(f"[{t0:.0f}] {' '.join(cur)}"); cur = []
    if cur: lines.append(f"[{t0:.0f}] {' '.join(cur)}")
    prompt = (f"Transcript with timestamps (seconds). Pick up to {config.MAX_CLIPS} most viral, self-contained "
              f"moments for Reels/Shorts (hype, funny, shocking, insight, reactions). Each {config.CLIP_MIN}-{config.CLIP_MAX} "
              f"seconds, start on a strong hook, end on a payoff, no overlaps. Video length {duration:.0f}s. "
              'Title = catchy hook under 8 words. Reply ONLY JSON: [{"start":num,"end":num,"title":"str","score":1-10}]\n\n'
              + "\n".join(lines)[:60000])
    txt = ask(prompt)
    if not txt: return None
    return json.loads(txt[txt.index("["): txt.rindex("]") + 1])

def pick_highlights(path, words, duration):
    clips = None
    if words:
        try: clips = llm_pick(words, duration)
        except Exception as ex: print("LLM failed, fallback:", ex)
    if not clips: clips = energy_candidates(path, duration)
    out = []
    for c in clips:
        s, e = float(c["start"]), float(c["end"])
        e = min(max(e, s + config.CLIP_MIN), s + config.CLIP_MAX, duration)
        if e - s >= 3: out.append({**c, "start": s, "end": e})
    return out[:config.MAX_CLIPS]
