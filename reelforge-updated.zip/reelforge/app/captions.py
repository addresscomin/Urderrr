# style: (highlight colour BGR, font size, bottom margin, uppercase)
STYLES = {"hype": ("&H0000FFFF", 84, 520, 1), "neon": ("&H0000FF00", 84, 520, 1),
          "fire": ("&H000080FF", 90, 520, 1), "clean": ("&H00FFFFFF", 70, 460, 0)}

def _t(s):
    s = max(s, 0); return f"{int(s//3600)}:{int(s%3600//60):02d}:{s%60:05.2f}"

def retext(ws, text, start, end):
    """User-edited caption text ko original timings par map karo."""
    toks = text.split()
    if not toks: return []
    if len(toks) == len(ws): return [{**w, "w": t} for w, t in zip(ws, toks)]
    a, b = (ws[0]["start"], ws[-1]["end"]) if ws else (start, end)
    d = (b - a) / len(toks)
    return [{"w": t, "start": a + i * d, "end": a + (i + 1) * d} for i, t in enumerate(toks)]

def make_ass(words, start, end, path, style="hype", per_line=3):
    hl, fs, mv, up = STYLES.get(style, STYLES["hype"])
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Cap,Arial,{fs},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,2,2,60,60,{mv},1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    f = (lambda x: x.upper()) if up else (lambda x: x)
    ws = [w for w in words if w["start"] >= start - 0.01 and w["end"] <= end + 0.01]
    out = []
    for i in range(0, len(ws), per_line):
        ch = ws[i:i + per_line]
        for j, w in enumerate(ch):
            txt = " ".join(("{\\c" + hl + "&\\fscx115\\fscy115}" + f(c["w"]) + "{\\r}") if k == j else f(c["w"])
                           for k, c in enumerate(ch))
            a = w["start"] - start
            b = (ch[j + 1]["start"] if j + 1 < len(ch) else w["end"]) - start
            out.append(f"Dialogue: 0,{_t(a)},{_t(max(b, a + .05))},Cap,,0,0,0,,{txt}")
    path.write_text(head + "\n".join(out), encoding="utf-8")
