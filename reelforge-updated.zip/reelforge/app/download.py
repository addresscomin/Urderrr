import subprocess
from pathlib import Path

def download(url: str, out_dir: Path) -> Path:
    out = out_dir / "source.mp4"
    subprocess.run(["yt-dlp", "-f", "bv*[height<=1080]+ba/b[height<=1080]",
                    "--no-playlist", "--merge-output-format", "mp4", "-o", str(out), url], check=True)
    return out
