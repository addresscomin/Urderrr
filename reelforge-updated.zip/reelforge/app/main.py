import uuid, threading, shutil, re, time, os
from pathlib import Path
from urllib.parse import urlparse
from fastapi import FastAPI, Form, UploadFile, File, Request, Response, HTTPException, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from . import config, db
from .pipeline import run, render_one

app = FastAPI(title="ReelForge", version="1.1.0")
SEM = threading.Semaphore(config.WORKERS)
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "2048"))
ALLOWED_EXT = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}
ALLOWED_HOSTS = {"youtube.com", "www.youtube.com", "youtu.be", "m.youtube.com", "vimeo.com", "www.vimeo.com"}

class Cred(BaseModel):
    email: str
    password: str
class Edit(BaseModel):
    text: str
    style: str = "hype"
    start: float
    end: float

def me(req: Request):
    u = db.user(req.cookies.get("t"))
    if not u: raise HTTPException(401, "Pehle login karo")
    return u

def _cookie(resp, token):
    resp.set_cookie("t", token, httponly=True, secure=os.getenv("COOKIE_SECURE", "0") == "1",
                    samesite="lax", max_age=60 * 60 * 24 * 30, path="/")

@app.post("/api/signup")
def signup(c: Cred, resp: Response):
    e = c.email.strip().lower()
    if len(e) > 254 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", e) or not 8 <= len(c.password) <= 128:
        raise HTTPException(400, "Valid email aur 8-128 character password do")
    token = db.signup(e, c.password)
    if not token: raise HTTPException(400, "Ye email pehle se registered hai")
    _cookie(resp, token); return db.user(token)

@app.post("/api/login")
def login(c: Cred, resp: Response):
    token = db.login(c.email.strip().lower(), c.password)
    if not token: raise HTTPException(400, "Email ya password galat hai")
    _cookie(resp, token); return db.user(token)

@app.post("/api/logout")
def logout(req: Request, resp: Response):
    db.logout(req.cookies.get("t", "")); resp.delete_cookie("t", path="/"); return {}

@app.get("/api/me")
def whoami(u=Depends(me)): return u

@app.get("/api/quota")
def quota(u=Depends(me)):
    return {"credits": u["credits"], "monthly_free_credits": config.FREE_CREDITS}

def worker(jid, uid, url, file_path, layout, style, limit):
    try:
        with SEM:
            db.job_set(jid, status="processing")
            result = run(config.DATA / jid, url, file_path, layout, style, limit,
                         lambda state: db.job_set(jid, status=state))
        db.settle_job(jid, len(result))
        db.job_set(jid, status="done", clips=result)
    except Exception as exc:
        db.refund_job(jid)
        db.job_set(jid, status="error", error=str(exc)[:300])

@app.post("/api/jobs")
async def create(url: str = Form(""), layout: str = Form("blur"), style: str = Form("hype"),
                 file: UploadFile | None = File(None), u=Depends(me)):
    has_file = bool(file and file.filename)
    if not has_file and not url.strip(): raise HTTPException(400, "Video link ya file do")
    if url:
        parsed = urlparse(url.strip())
        if parsed.scheme != "https" or (parsed.hostname or "").lower() not in ALLOWED_HOSTS:
            raise HTTPException(400, "Abhi sirf supported YouTube/Vimeo links ya direct upload allowed hai")
    layout = layout if layout in ("blur", "crop") else "blur"
    style = style if style in ("hype", "neon", "fire", "clean") else "hype"
    jid = uuid.uuid4().hex[:12]
    job_dir = config.DATA / jid
    job_dir.mkdir(parents=True, exist_ok=False)
    file_path = None
    if has_file:
        ext = Path(file.filename or "").suffix.lower()
        if ext not in ALLOWED_EXT:
            shutil.rmtree(job_dir, ignore_errors=True)
            raise HTTPException(400, "MP4, MOV, MKV, WEBM ya M4V file upload karo")
        file_path = job_dir / ("upload" + ext)
        size = 0
        try:
            with open(file_path, "wb") as out:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_UPLOAD_MB * 1024 * 1024:
                        raise HTTPException(413, f"Upload limit {MAX_UPLOAD_MB} MB hai")
                    out.write(chunk)
        except Exception:
            shutil.rmtree(job_dir, ignore_errors=True)
            raise
        finally:
            await file.close()
    reserve = db.reserve_job(jid, u["id"], config.MAX_CLIPS)
    if reserve < 1:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(402, "Free credits khatam ho gaye")
    threading.Thread(target=worker, args=(jid, u["id"], url or None, file_path, layout, style, reserve), daemon=True).start()
    return {"id": jid, "reserved_credits": reserve}

@app.get("/api/jobs")
def jobs(u=Depends(me)): return db.jobs_of(u["id"])

def _own(jid, u):
    if not re.fullmatch(r"[a-f0-9]{12}", jid): raise HTTPException(404, "Not found")
    j = db.job_get(jid)
    if not j or j["uid"] != u["id"]: raise HTTPException(404, "Not found")
    return j

@app.post("/api/jobs/{jid}/clips/{i}")
def edit(jid: str, i: int, e: Edit, u=Depends(me)):
    j = _own(jid, u)
    clip = next((c for c in j["clips"] if c["i"] == i), None)
    if not clip: raise HTTPException(404, "Clip nahi mila")
    if not 3 <= e.end - e.start <= 60 or e.start < 0: raise HTTPException(400, "Clip 3-60 second ka rakho")
    if e.style not in ("hype", "neon", "fire", "clean"): raise HTTPException(400, "Invalid caption style")
    with SEM: new = render_one(config.DATA / jid, clip, e.text[:3000], e.style, e.start, e.end)
    new["v"] = int(time.time())
    j["clips"] = [new if c["i"] == i else c for c in j["clips"]]
    db.job_set(jid, clips=j["clips"]); return new

@app.get("/files/{jid}/{name}")
def files(jid: str, name: str, u=Depends(me)):
    _own(jid, u)
    safe = Path(name).name
    target = (config.DATA / jid / safe).resolve()
    if target.parent != (config.DATA / jid).resolve() or not target.is_file():
        raise HTTPException(404, "File not found")
    return FileResponse(target, filename=safe)

app.mount("/", StaticFiles(directory="web", html=True), name="web")
