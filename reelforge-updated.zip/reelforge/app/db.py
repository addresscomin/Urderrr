import sqlite3, hashlib, secrets, json, time, threading
from . import config

DB_PATH = config.DATA / "app.db"
_l = threading.RLock()

def _conn():
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=30000")
    return c

with _conn() as c:
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pw TEXT NOT NULL,
      salt TEXT NOT NULL, credits INTEGER NOT NULL DEFAULT 20 CHECK(credits >= 0));
    CREATE TABLE IF NOT EXISTS sessions(
      token TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS jobs(
      id TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL, error TEXT NOT NULL DEFAULT '', clips TEXT NOT NULL DEFAULT '[]',
      created REAL NOT NULL, reserved INTEGER NOT NULL DEFAULT 0);
    CREATE INDEX IF NOT EXISTS jobs_uid_created ON jobs(uid, created DESC);
    CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires);
    """)

def Q(sql, *a):
    with _l, _conn() as c:
        return c.execute(sql, a).fetchall()

def _h(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 300000).hex()

def signup(email, pw):
    salt = secrets.token_hex(16)
    try:
        with _l, _conn() as c:
            c.execute("INSERT INTO users(email,pw,salt,credits) VALUES(?,?,?,?)",
                      (email, _h(pw, salt), salt, config.FREE_CREDITS))
    except sqlite3.IntegrityError:
        return None
    return login(email, pw)

def login(email, pw):
    rows = Q("SELECT * FROM users WHERE email=?", email)
    if not rows or not secrets.compare_digest(rows[0]["pw"], _h(pw, rows[0]["salt"])):
        return None
    token = secrets.token_urlsafe(32)
    with _l, _conn() as c:
        c.execute("DELETE FROM sessions WHERE expires < ?", (time.time(),))
        c.execute("INSERT INTO sessions(token,uid,expires) VALUES(?,?,?)",
                  (token, rows[0]["id"], time.time() + 60 * 60 * 24 * 30))
    return token

def logout(token):
    if token:
        Q("DELETE FROM sessions WHERE token=?", token)

def user(token):
    rows = Q("SELECT u.id,u.email,u.credits FROM sessions s JOIN users u ON u.id=s.uid WHERE s.token=? AND s.expires>?",
             token, time.time()) if token else []
    return dict(rows[0]) if rows else None

def reserve_job(jid, uid, max_clips):
    """Atomically reserve up to max_clips credits before accepting work."""
    with _l, _conn() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT credits FROM users WHERE id=?", (uid,)).fetchone()
        if not row or row["credits"] < 1:
            return 0
        reserve = min(int(max_clips), int(row["credits"]))
        c.execute("UPDATE users SET credits=credits-? WHERE id=?", (reserve, uid))
        c.execute("INSERT INTO jobs(id,uid,status,created,reserved) VALUES(?,?,?,?,?)",
                  (jid, uid, "queued", time.time(), reserve))
        return reserve

def settle_job(jid, used):
    """Refund unused reserved credits once the worker has finished."""
    with _l, _conn() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT uid,reserved FROM jobs WHERE id=?", (jid,)).fetchone()
        if not row:
            return
        refund = max(0, int(row["reserved"]) - max(0, int(used)))
        if refund:
            c.execute("UPDATE users SET credits=credits+? WHERE id=?", (refund, row["uid"]))
        c.execute("UPDATE jobs SET reserved=0 WHERE id=?", (jid,))

def refund_job(jid):
    with _l, _conn() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT uid,reserved FROM jobs WHERE id=?", (jid,)).fetchone()
        if row and row["reserved"]:
            c.execute("UPDATE users SET credits=credits+? WHERE id=?", (row["reserved"], row["uid"]))
            c.execute("UPDATE jobs SET reserved=0 WHERE id=?", (jid,))

def job_set(jid, status=None, error=None, clips=None):
    fields, values = [], []
    if status is not None: fields.append("status=?"); values.append(status)
    if error is not None: fields.append("error=?"); values.append(error)
    if clips is not None: fields.append("clips=?"); values.append(json.dumps(clips))
    if fields: Q("UPDATE jobs SET " + ",".join(fields) + " WHERE id=?", *values, jid)

def _j(row):
    d = dict(row); d["clips"] = json.loads(d["clips"] or "[]"); return d

def job_get(jid):
    rows = Q("SELECT * FROM jobs WHERE id=?", jid)
    return _j(rows[0]) if rows else None

def jobs_of(uid):
    return [_j(r) for r in Q("SELECT * FROM jobs WHERE uid=? ORDER BY created DESC LIMIT 30", uid)]
