# ReelForge — AI video clipper

Upload a video or submit a supported YouTube/Vimeo link. ReelForge transcribes speech with Faster-Whisper, asks configured AI providers to identify short highlights (audio-energy fallback if no provider is available), then renders vertical 9:16 clips with styled captions. Users can edit captions and re-render clips.

## Run locally

```bash
# Install FFmpeg first (Ubuntu/Debian: sudo apt-get install ffmpeg fonts-liberation)
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Add at least one AI provider key to .env for transcript-based highlight selection.
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000. Data and SQLite database are stored under `DATA_DIR` (default `data`).

## Docker

```bash
docker build -t reelforge .
docker run --rm -p 8000:8000 --env-file .env -v "$PWD/data:/srv/data" reelforge
```

## Providers

Configure one or more keys in `.env`: `GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`. Keys are server-side only. Provider free tiers, model availability, and rate limits can change; paid API use is not required for the audio-energy fallback.

## Important limits

- Default free allowance is 20 credits per account. A job reserves credits atomically; unused credits are refunded after completion, and failed jobs refund their reservation.
- Upload limit defaults to 2048 MB (`MAX_UPLOAD_MB`). Change only after ensuring enough disk space.
- `WORKERS=1` is the safe default for small machines. Each job requires CPU, memory, disk, and FFmpeg/Whisper runtime; 10-hour videos are not guaranteed on low-memory/free hosting.
- YouTube/Vimeo URL support depends on provider access and may fail. Uploading your own file is the reliable path.
- Use only videos you own or have permission to process. This project does not bypass access controls or DRM.
- For public HTTPS deployment, set `COOKIE_SECURE=1`, use a reverse proxy with TLS, configure rate limiting and backups, and place `DATA_DIR` on persistent storage. Do not expose the service directly without these controls.
- SQLite is suitable for a single-instance starter deployment. For multi-instance production, migrate to managed PostgreSQL and a durable background queue.
