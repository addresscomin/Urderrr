import sys
from pathlib import Path
from app.pipeline import run
# usage: python cli.py <youtube-url> [blur|crop]
res = run(Path("data/cli"), url=sys.argv[1], layout=sys.argv[2] if len(sys.argv) > 2 else "blur", progress=print)
print(*[f"{r['file']}  {r['title']}" for r in res], sep="\n")
