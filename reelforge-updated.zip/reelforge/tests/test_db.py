import tempfile
from pathlib import Path

# Exercise the credit/session primitives against an isolated SQLite database.
from app import config, db


def test_credit_reservation_and_refund():
    token = db.signup("test-reelforge@example.invalid", "strong-pass-123")
    assert token
    user = db.user(token)
    assert user["credits"] == config.FREE_CREDITS
    reserved = db.reserve_job("a1b2c3d4e5f6", user["id"], 10)
    assert reserved == min(10, config.FREE_CREDITS)
    assert db.user(token)["credits"] == config.FREE_CREDITS - reserved
    db.settle_job("a1b2c3d4e5f6", 2)
    assert db.user(token)["credits"] == config.FREE_CREDITS - 2


def test_failed_job_refunds_all_reserved_credits():
    token = db.signup("test-failure@example.invalid", "strong-pass-123")
    user = db.user(token)
    reserved = db.reserve_job("f1e2d3c4b5a6", user["id"], 7)
    assert reserved == 7
    db.refund_job("f1e2d3c4b5a6")
    assert db.user(token)["credits"] == config.FREE_CREDITS
