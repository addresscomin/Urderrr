plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.me.discipline"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.me.focusguard"
        minSdk = 26
        targetSdk = 34
        versionCode = 9
        versionName = "8.0"
    }
    // One fixed signing key, so every new build can update the previous one.
    signingConfigs {
        create("fixed") {
            storeFile = file("fixed-debug.keystore")
            storePassword = "android"
            keyAlias = "focusguard"
            keyPassword = "android"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("fixed") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
