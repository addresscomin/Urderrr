package com.me.discipline

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Discipline Analytics & Scoring Engine:
 * - Computes real-time daily score (0-100%)
 * - Tracks consistency streak
 * - Stores & retrieves 7-day performance history
 */
object Analytics {

    data class DayScore(
        val dayKey: String,
        val dayLabel: String,
        val score: Int,
        val screenTimeMin: Int,
        val prayersDone: Int,
        val tasksDone: Int,
        val lies: Int
    )

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("analytics", Context.MODE_PRIVATE)

    /** Calculate today's discipline score (0 - 100) based on all modules. */
    fun calculateTodayScore(c: Context): Int {
        val now = System.currentTimeMillis()
        val limitMin = Prefs.dailyLimitMin(c)
        val usedMin = (Prefs.used(c) / 60000L).toInt()

        // 1. Screen Time Points (Max 30)
        val screenPoints = when {
            usedMin <= limitMin * 0.5f -> 30
            usedMin <= limitMin * 0.8f -> 25
            usedMin <= limitMin -> 20
            else -> 0
        }

        // 2. Prayer Points (Max 30)
        var prayerPoints = 30
        if (NamazPrefs.enabled(c)) {
            val day = Prefs.dayKey(now)
            var done = 0
            var due = 0
            val prayers = PrayerTimes.day(c, 0).prayers
            for (p in prayers) {
                if (now >= p.start) {
                    due++
                    if (NamazPrefs.done(c, day, p.idx)) done++
                }
            }
            prayerPoints = if (due > 0) ((done.toFloat() / due) * 30).toInt() else 30
        }

        // 3. Timetable Points (Max 30)
        val tasks = Timetable.all(c)
        var taskPoints = 30
        if (tasks.isNotEmpty()) {
            val day = Prefs.dayKey(now)
            var done = 0
            var due = 0
            for (t in tasks) {
                val base = TimeUtil.midnight(0)
                if (now >= base + t.start * 60000L) {
                    due++
                    if (Timetable.done(c, day, t.id)) done++
                }
            }
            taskPoints = if (due > 0) ((done.toFloat() / due) * 30).toInt() else 30
        }

        // 4. Honesty / Voice Points (Max 10)
        val lies = Prefs.int(c, "lie_" + Prefs.dayKey(now), 0)
        val honestyPoints = when {
            lies == 0 -> 10
            lies <= Config.VOICE_FREE_WARNINGS -> 5
            else -> 0
        }

        val total = (screenPoints + prayerPoints + taskPoints + honestyPoints).coerceIn(0, 100)

        // Save today's snapshot
        saveSnapshot(c, Prefs.dayKey(now), total, usedMin, lies)

        return total
    }

    private fun saveSnapshot(c: Context, dayKey: String, score: Int, usedMin: Int, lies: Int) {
        val o = JSONObject()
        o.put("score", score)
        o.put("used", usedMin)
        o.put("lies", lies)
        sp(c).edit().putString("snap_$dayKey", o.toString()).apply()
    }

    /** Returns consecutive days with score >= 70%. */
    fun getStreakDays(c: Context): Int {
        var streak = 0
        val cal = Calendar.getInstance()
        // Check backwards up to 30 days
        for (i in 0..30) {
            val key = SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)
            val raw = sp(c).getString("snap_$key", null)
            val score = if (raw != null) {
                try { JSONObject(raw).optInt("score", 0) } catch (e: Exception) { 0 }
            } else if (i == 0) {
                calculateTodayScore(c)
            } else {
                0
            }

            if (score >= 60) {
                streak++
            } else if (i > 0) {
                break
            }
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return streak
    }

    /** Returns 7-day history for the bar chart. */
    fun getPastWeek(c: Context): List<DayScore> {
        val list = ArrayList<DayScore>()
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -6)

        for (i in 0..6) {
            val time = cal.time
            val key = SimpleDateFormat("yyyyMMdd", Locale.US).format(time)
            val dayLabel = SimpleDateFormat("EEE", Locale.US).format(time)
            val isToday = (i == 6)

            var score = 0
            var used = 0
            var lies = 0

            val raw = sp(c).getString("snap_$key", null)
            if (raw != null) {
                try {
                    val o = JSONObject(raw)
                    score = o.optInt("score", 0)
                    used = o.optInt("used", 0)
                    lies = o.optInt("lies", 0)
                } catch (e: Exception) {}
            } else if (isToday) {
                score = calculateTodayScore(c)
                used = (Prefs.used(c) / 60000L).toInt()
                lies = Prefs.int(c, "lie_$key", 0)
            }

            // Count prayers & tasks done on that day
            var prayersDone = 0
            if (NamazPrefs.enabled(c)) {
                for (pIdx in 0..4) {
                    if (NamazPrefs.done(c, key, pIdx)) prayersDone++
                }
            }
            var tasksDone = 0
            for (t in Timetable.all(c)) {
                if (Timetable.done(c, key, t.id)) tasksDone++
            }

            list.add(DayScore(key, dayLabel, score, used, prayersDone, tasksDone, lies))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return list
    }
}
