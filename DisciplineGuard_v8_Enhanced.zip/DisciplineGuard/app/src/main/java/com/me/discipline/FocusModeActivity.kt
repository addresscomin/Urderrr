package com.me.discipline

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Deep Focus & Study Mode (Pomodoro Engine):
 * Full distraction-free focus sessions with custom durations,
 * real-time ambient noise synthesizer, and glowing progress timer.
 */
class FocusModeActivity : Activity() {

    private var durationMin = 25
    private var millisLeft = 25 * 60 * 1000L
    private var isRunning = false
    private var timer: CountDownTimer? = null

    private lateinit var ring: CircleProgressView
    private lateinit var timeDisplay: TextView
    private lateinit var startBtn: TextView
    private lateinit var soundBtn: TextView
    private var currentSound = FocusSoundGenerator.SoundType.RAIN

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val d = Ui.dp(this, 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#09090F"), Color.parseColor("#121224"), Color.parseColor("#09090F"))
            )
            setPadding(20 * d, 44 * d, 20 * d, 30 * d)
        }

        // Top bar
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = Ui.pill(this, "✕ Exit", Ui.CARD_ELEVATED, Ui.LABEL) { finish() }
        val title = Ui.text(this, "Deep Focus Session", 18f, Ui.LABEL, true).apply {
            gravity = Gravity.CENTER
        }
        topBar.addView(backBtn)
        topBar.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(Ui.badge(this, "DISTRACTION-FREE", Ui.CARD_ELEVATED, Ui.INDIGO_LIGHT))
        root.addView(topBar, Ui.lp(this))

        // Duration selector chips
        val durRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 16 * d, 0, 8 * d)
        }
        val durations = listOf(15, 25, 45, 60)
        for (mins in durations) {
            val chip = TextView(this).apply {
                text = "${mins}m"
                textSize = 13f
                setTextColor(if (mins == durationMin) Color.WHITE else Ui.MUTED)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                background = Ui.rounded(
                    if (mins == durationMin) Ui.INDIGO else Ui.CARD_ELEVATED,
                    12f * d,
                    Ui.CARD_BORDER,
                    1 * d
                )
                setPadding(16 * d, 8 * d, 16 * d, 8 * d)
                isClickable = true
                setOnClickListener {
                    if (isRunning) {
                        Toast.makeText(this@FocusModeActivity, "End current session first", Toast.LENGTH_SHORT).show()
                    } else {
                        durationMin = mins
                        millisLeft = mins * 60 * 1000L
                        updateDisplay()
                        ring.setProgress(0f, 100f)
                    }
                }
            }
            durRow.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(6 * d, 0, 6 * d, 0)
            })
        }
        root.addView(durRow)

        // Center Ring + Timer
        val ringBox = FrameLayout(this).apply {
            ring = CircleProgressView(this@FocusModeActivity)
            timeDisplay = Ui.text(this@FocusModeActivity, "25:00", 42f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
            }
            addView(ring, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(timeDisplay, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        root.addView(ringBox, LinearLayout.LayoutParams(250 * d, 250 * d).apply {
            topMargin = 16 * d
            bottomMargin = 16 * d
        })

        // Motivation quote
        val quote = Quotes.randomMotivation("hi")
        val quoteBox = Ui.card(this, true).apply {
            addView(Ui.text(this@FocusModeActivity, "\"${quote.text}\"", 13f, Ui.LABEL).apply {
                gravity = Gravity.CENTER
            })
            addView(Ui.text(this@FocusModeActivity, "— ${quote.author}", 11f, Ui.INDIGO_LIGHT).apply {
                gravity = Gravity.CENTER
                setPadding(0, 4 * d, 0, 0)
            })
        }
        root.addView(quoteBox, Ui.lp(this, 8, 16))

        // Sound Mode Toggle
        soundBtn = Ui.pill(this, "🌧️ Ambient: Rain (Tap to change)", Ui.CARD_ELEVATED, Ui.LABEL) {
            cycleSound()
        }
        root.addView(soundBtn, Ui.lp(this, 4, 10))

        // Main Action Button (Start / Stop)
        startBtn = Ui.gradientButton(this, "START DEEP FOCUS", Ui.INDIGO, Ui.INDIGO_LIGHT) {
            toggleTimer()
        }
        root.addView(startBtn, Ui.lp(this, 10, 0))

        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(root)
        }
        setContentView(sv)

        updateDisplay()
    }

    private fun cycleSound() {
        currentSound = when (currentSound) {
            FocusSoundGenerator.SoundType.RAIN -> FocusSoundGenerator.SoundType.WHITE_NOISE
            FocusSoundGenerator.SoundType.WHITE_NOISE -> FocusSoundGenerator.SoundType.ZEN_PULSE
            FocusSoundGenerator.SoundType.ZEN_PULSE -> FocusSoundGenerator.SoundType.NONE
            FocusSoundGenerator.SoundType.NONE -> FocusSoundGenerator.SoundType.RAIN
        }
        val label = when (currentSound) {
            FocusSoundGenerator.SoundType.RAIN -> "🌧️ Ambient: Rain"
            FocusSoundGenerator.SoundType.WHITE_NOISE -> "💨 Ambient: White Noise"
            FocusSoundGenerator.SoundType.ZEN_PULSE -> "🧘 Ambient: Zen 432Hz"
            FocusSoundGenerator.SoundType.NONE -> "🔇 Ambient: Mute"
        }
        soundBtn.text = "$label (Tap to change)"
        if (isRunning) FocusSoundGenerator.start(currentSound)
    }

    private fun toggleTimer() {
        if (isRunning) {
            timer?.cancel()
            isRunning = false
            startBtn.text = "RESUME FOCUS"
            FocusSoundGenerator.stop()
        } else {
            isRunning = true
            startBtn.text = "PAUSE FOCUS"
            FocusSoundGenerator.start(currentSound)

            val totalMs = durationMin * 60 * 1000L
            timer = object : CountDownTimer(millisLeft, 1000L) {
                override fun onTick(ms: Long) {
                    millisLeft = ms
                    updateDisplay()
                    val passed = (totalMs - ms).toFloat()
                    ring.setProgress(passed, totalMs.toFloat())
                }

                override fun onFinish() {
                    isRunning = false
                    millisLeft = totalMs
                    updateDisplay()
                    ring.setProgress(totalMs.toFloat(), totalMs.toFloat())
                    startBtn.text = "START NEW SESSION"
                    FocusSoundGenerator.stop()
                    VoiceService.speak(this@FocusModeActivity, "done", 0, 0)
                    Toast.makeText(this@FocusModeActivity, "Great job! Focus session completed 🎉", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }

    private fun updateDisplay() {
        val s = (millisLeft / 1000).coerceAtLeast(0)
        timeDisplay.text = String.format("%02d:%02d", s / 60, s % 60)
    }

    override fun onDestroy() {
        timer?.cancel()
        FocusSoundGenerator.stop()
        super.onDestroy()
    }
}
