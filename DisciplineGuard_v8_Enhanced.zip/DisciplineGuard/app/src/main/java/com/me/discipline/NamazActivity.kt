package com.me.discipline

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import kotlin.math.abs

/** NAMAZ MODULE ka alag screen: ON/OFF, waqt, deadline, location, saboot record. */
class NamazActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked"); finish(); return
        }
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun d(v: Int) = Ui.dp(this, v)

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(48), d(16), d(48)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        sv.addView(col)
        setContentView(sv)

        val strict = Prefs.strict(this)
        val enabled = NamazPrefs.enabled(this)

        col.addView(Ui.text(this, "Prayer Guard", 30f, Ui.LABEL, true).apply { setPadding(d(4), 0, 0, 0) })

        val st = Ui.cardIn(this, col)
        Ui.row(this, st, "Prayer module", if (enabled) "ON ✅" else "OFF", if (enabled) Ui.GREEN else Ui.RED) {
            if (Prefs.armed(this)) toast("This cannot be changed after activation.")
            else { NamazPrefs.setEnabled(this, !enabled); render() }
        }
        Ui.row(this, st, "Prayer proofs (photos)", "${NamazPrefs.proofCount(this)} saved")
        if (!enabled) {
            st.addView(Ui.text(this, "Module is OFF: the phone will not lock at prayer time and missed prayers carry no penalty.", 12f, Ui.SUB)
                .apply { setPadding(0, d(8), 0, d(8)) })
            return
        }

        Ui.section(this, col, "Prayer times (tap to change)")
        val tc = Ui.cardIn(this, col)
        val cur = PrayerTimes.currentMinutes(this)
        val dayKey = Prefs.dayKey()
        val now = System.currentTimeMillis()
        for (i in 0..4) {
            val isDone = NamazPrefs.done(this, dayKey, i)
            val isMissed = NamazPrefs.missed(this, dayKey, i)
            val activeP = PrayerTimes.active(this, now)
            val isActive = activeP != null && activeP.idx == i

            val (statusText, statusCol) = when {
                isDone -> Pair("Done ✅", Ui.GREEN)
                isActive -> Pair("Active ▶", Ui.INDIGO_LIGHT)
                isMissed -> Pair("Missed ❌", Ui.RED)
                else -> Pair(TimeUtil.fmtMin(cur[i]), Ui.BLUE)
            }
            Ui.row(this, tc, PrayerTimes.NAMES[i], statusText, statusCol, "Calculated: ${TimeUtil.fmtMin(cur[i])}") { editTime(i, cur[i]) }
        }
        tc.addView(Ui.text(this,
            if (NamazPrefs.manualTimes(this) != null) "Your saved times are in use." else "Times are currently calculated from your location. Changing any time saves all five.",
            12f, Ui.SUB).apply { setPadding(0, d(8), 0, d(4)) })
        if (NamazPrefs.manualTimes(this) != null) {
            tc.addView(Ui.pill(this, "Reset to calculated times", Ui.BG, Ui.BLUE) {
                if (PrayerTimes.active(this) != null) toast("Cannot change this during prayer time.")
                else { NamazPrefs.clearManualTimes(this); Scheduler.rescheduleAll(this); render() }
            }, Ui.lp(this, 6))
        }
        if (strict) tc.addView(Ui.text(this, "After activation, times can only shift ±30 min from the calculated time.", 12f, Ui.SUB))

        Ui.section(this, col, "Settings")
        val sc = Ui.cardIn(this, col)
        val etWin = Ui.field(this, sc, "Prayer deadline (minutes after start)", NamazPrefs.windowMin(this).toString())
        val etLat = Ui.field(this, sc, "Latitude", NamazPrefs.lat(this).toString(), true)
        val etLng = Ui.field(this, sc, "Longitude", NamazPrefs.lng(this).toString(), true)
        sc.addView(Ui.pill(this, "Save", Ui.BLUE, Color.WHITE) {
            val w = (etWin.text.toString().toIntOrNull() ?: NamazPrefs.windowMin(this)).coerceIn(30, 180)
            if (Prefs.strict(this) && w > NamazPrefs.windowMin(this)) {
                toast("The deadline cannot be extended after activation.")
            } else {
                NamazPrefs.setWindowMin(this, w)
                if (!Prefs.strict(this)) {
                    val la = etLat.text.toString().toDoubleOrNull()
                    val lo = etLng.text.toString().toDoubleOrNull()
                    if (la != null && lo != null) {
                        NamazPrefs.setStr(this, "lat", la.toString()); NamazPrefs.setStr(this, "lng", lo.toString())
                    }
                }
                Scheduler.rescheduleAll(this)
                toast("Saved")
                render()
            }
        }, Ui.lp(this, 14))
        sc.addView(Ui.pill(this, "Use my location", Ui.BG, Ui.BLUE) { useLocation() }, Ui.lp(this, 10))
        sc.addView(Ui.pill(this, "Test voice", Ui.BG, Ui.BLUE) { VoiceService.speak(this, "adhan", 1, 0) }, Ui.lp(this, 10))
        sc.addView(View(this), Ui.lp(this, 6))

        col.addView(Ui.text(this,
            "Rules: the phone locks at prayer time (calls only). After 5 minutes, submit a LIVE camera photo as proof. No proof by the deadline counts as missed: the first miss locks the phone for 60 min, each further miss adds 30 min, and all five missed means 24 hours.",
            12f, Ui.SUB).apply { setPadding(d(4), d(14), 0, 0) })
    }

    private fun editTime(i: Int, curMin: Int) {
        if (PrayerTimes.active(this) != null) { toast("Cannot change times during prayer time."); return }
        TimePickerDialog(this, { _, hh, mm ->
            val v = hh * 60 + mm
            val calc = PrayerTimes.calcMinutes(this)[i]
            if (Prefs.strict(this) && abs(v - calc) > 30) {
                toast("After activation you can only shift ±30 min from the calculated time (${TimeUtil.fmtMin(calc)}).")
            } else {
                val arr = PrayerTimes.currentMinutes(this).copyOf()
                arr[i] = v
                NamazPrefs.setManualTimes(this, arr)
                Scheduler.rescheduleAll(this)
                toast("${PrayerTimes.NAMES[i]} time saved")
                render()
            }
        }, curMin / 60, curMin % 60, false).show()
    }

    private fun useLocation() {
        if (Prefs.strict(this)) { toast("Location cannot be changed after activation."); return }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2); return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
                .maxByOrNull { it.time }
            if (loc == null) {
                toast("Location not found. Turn on GPS, open Maps once, then try again.")
            } else {
                NamazPrefs.setStr(this, "lat", loc.latitude.toString())
                NamazPrefs.setStr(this, "lng", loc.longitude.toString())
                Scheduler.rescheduleAll(this)
                toast("Location set")
                render()
            }
        } catch (e: Exception) { toast("Location error") }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
