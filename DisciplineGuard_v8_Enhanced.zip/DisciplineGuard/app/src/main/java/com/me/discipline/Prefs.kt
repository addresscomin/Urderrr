package com.me.discipline

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Core store ("guard"): activation, daily usage, limits, and lock. */
object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun long(c: Context, k: String, d: Long = 0L): Long = sp(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }

    fun dayKey(ms: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    // ---- activation (one-way: permanent once activated) ----
    fun armed(c: Context) = bool(c, "armed")
    fun strict(c: Context) = bool(c, "strict")
    fun armedAt(c: Context) = long(c, "armedAt")
    fun activate(c: Context) {
        if (armed(c)) return
        setBool(c, "armed", true)
        setBool(c, "strict", true)
        setLong(c, "armedAt", System.currentTimeMillis())
    }

    // ---- configurable rules (customizable before activation) ----
    fun dailyLimitMin(c: Context): Int = int(c, "dailyLimitMin", Config.DAILY_LIMIT_MIN)
    fun setDailyLimitMin(c: Context, v: Int) {
        if (!strict(c)) setInt(c, "dailyLimitMin", v.coerceIn(30, 720))
    }

    fun sleepStartMin(c: Context): Int = int(c, "sleepStartMin", Config.SLEEP_START_MIN)
    fun setSleepStartMin(c: Context, v: Int) {
        if (!strict(c)) setInt(c, "sleepStartMin", v)
    }

    fun sleepEndMin(c: Context): Int = int(c, "sleepEndMin", Config.SLEEP_END_MIN)
    fun setSleepEndMin(c: Context, v: Int) {
        if (!strict(c)) setInt(c, "sleepEndMin", v)
    }

    fun emergencyNumber(c: Context): String = str(c, "emergencyNumber", "112")
    fun setEmergencyNumber(c: Context, num: String) {
        if (!strict(c)) setStr(c, "emergencyNumber", num)
    }

    // ---- lock (limit / missed prayer / missed task penalty) ----
    fun lockUntil(c: Context) = long(c, "lockUntil")
    fun lockReason(c: Context) = str(c, "lockReason", "locked")
    fun setLock(c: Context, until: Long, reason: String) {
        setLong(c, "lockUntil", until)
        setStr(c, "lockReason", reason)
    }
    /** Lock sirf badhta hai, kabhi chhota nahi hota. */
    fun extendLock(c: Context, until: Long, reason: String) {
        if (until > lockUntil(c)) setLock(c, until, reason)
    }

    // ---- daily usage ----
    private fun roll(c: Context) {
        val d = dayKey()
        if (str(c, "usedDay") != d) {
            setStr(c, "usedDay", d)
            setLong(c, "used", 0L)
        }
    }
    fun used(c: Context): Long { roll(c); return long(c, "used") }
    fun addUsed(c: Context, ms: Long) { roll(c); setLong(c, "used", long(c, "used") + ms) }
}
