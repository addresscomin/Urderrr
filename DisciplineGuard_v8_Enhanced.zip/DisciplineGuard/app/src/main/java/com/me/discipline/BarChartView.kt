package com.me.discipline

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * 7-Day Bar Chart for Discipline Score and Daily Screen Time.
 * Renders rounded bars, labels, and baseline cleanly.
 */
class BarChartView(context: Context) : View(context) {

    data class BarData(val dayLabel: String, val value: Float, val maxValue: Float, val isHighlight: Boolean = false)

    private var items: List<BarData> = emptyList()
    private val density = context.resources.displayMetrics.density

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bgBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#1C1C2E")
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * density
        textAlign = Paint.Align.CENTER
        color = Color.parseColor("#94A3B8")
    }
    private val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 10f * density
        textAlign = Paint.Align.CENTER
        color = Color.parseColor("#CBD5E1")
    }

    fun setData(data: List<BarData>) {
        this.items = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (items.isEmpty()) return

        val w = width.toFloat()
        val h = height.toFloat()
        val bottomMargin = 26f * density
        val topMargin = 24f * density
        val chartHeight = h - bottomMargin - topMargin

        val count = items.size
        val slotWidth = w / count
        val barWidth = minOf(slotWidth * 0.45f, 24f * density)
        val radius = barWidth / 2f

        for (i in 0 until count) {
            val item = items[i]
            val cx = slotWidth * i + slotWidth / 2f
            val left = cx - barWidth / 2f
            val right = cx + barWidth / 2f
            val bottom = h - bottomMargin
            val top = topMargin

            // Background placeholder bar
            canvas.drawRoundRect(RectF(left, top, right, bottom), radius, radius, bgBarPaint)

            // Value bar
            val ratio = (item.value / item.maxValue.coerceAtLeast(1f)).coerceIn(0f, 1f)
            val barTop = bottom - (chartHeight * ratio)

            val color = when {
                item.isHighlight -> Color.parseColor("#6366F1")
                ratio >= 0.8f -> Color.parseColor("#10B981")
                ratio >= 0.5f -> Color.parseColor("#F59E0B")
                else -> Color.parseColor("#EF4444")
            }
            barPaint.color = color

            if (barTop < bottom) {
                canvas.drawRoundRect(RectF(left, barTop, right, bottom), radius, radius, barPaint)
            }

            // Top value label
            canvas.drawText("${item.value.toInt()}%", cx, barTop - 6f * density, valPaint)

            // Bottom day label
            labelPaint.color = if (item.isHighlight) Color.WHITE else Color.parseColor("#94A3B8")
            canvas.drawText(item.dayLabel, cx, h - 8f * density, labelPaint)
        }
    }
}
