package com.me.discipline

import kotlin.random.Random

/**
 * Daily Mindset & Discipline Quotes Engine.
 * Supports Urdu, Hindi, and English.
 */
object Quotes {
    data class Quote(val text: String, val author: String, val lang: String)

    private val QUOTES = listOf(
        // Hindi / Hinglish
        Quote("अनुशासन ही आपके लक्ष्यों और सफलता के बीच का पुल है।", "जिम रोन", "hi"),
        Quote("वक्त की कद्र करो, जो आज मेहनत करेगा, कल वही राज करेगा।", "अज्ञात", "hi"),
        Quote("मन के हारे हार है, मन के जीते जीत। फोन को अपना मालिक मत बनने दो।", "संत कबीर", "hi"),
        Quote("कठिन फैसले आज लो, ताकि कल की जिंदगी आसान हो सके।", "मार्क्स ऑरेलियस", "hi"),
        Quote("नमाज़ और रूटीन आपको दुनिया की फिजूल बातों से बचाते हैं।", "आध्यात्मिक सीख", "hi"),
        Quote("फोकस वही है जो आपको भीड़ से अलग और कामयाब बनाता है।", "स्टीव जॉब्स", "hi"),
        Quote("आलस तात्कालिक सुख है जो भविष्य का सुख छीन लेता है।", "चाणक्य", "hi"),
        Quote("हर दिन एक नया मौका है खुद को साबित करने का। उठो और काम करो।", "विवेकानंद", "hi"),

        // Urdu
        Quote("وقت سب سے قیمتی دولت ہے، اسے فضول اسکرولنگ میں ضائع مت کریں۔", "حکمت", "ur"),
        Quote("نماز نیند اور فون دونوں سے بہتر ہے۔ اپنے رب کو یاد رکھیں۔", "فرمان", "ur"),
        Quote("خود پر قابو پا لینا ہی دنیا کی سب سے بڑی فتح ہے۔", "افلاطون", "ur"),
        Quote("جو آج وقت کی قدر نہیں کرتا، وقت کل اس کی قدر چھین لیتا ہے۔", "دانائی", "ur"),
        Quote("صبر اور استقامت سے ہی انسان بلندیوں کو چھوتا ہے۔", "علامہ اقبال", "ur"),
        Quote("اپنے مقاصد پر نظر رکھیں، خلفشار سے دور رہیں۔", "رہنمائی", "ur"),

        // English
        Quote("Discipline is choosing between what you want now and what you want most.", "Abraham Lincoln", "en"),
        Quote("We must all suffer one of two things: the pain of discipline or the pain of regret.", "Jim Rohn", "en"),
        Quote("Small daily improvements over time lead to stunning results.", "Robin Sharma", "en"),
        Quote("Mastering others is strength. Mastering yourself is true power.", "Lao Tzu", "en"),
        Quote("Prayer is the key to inner peace and the shield against distraction.", "Wisdom", "en"),
        Quote("Do not let the phone control your life; take back control of your mind.", "Discipline Guard", "en"),
        Quote("Focus is a muscle. The more you practice resisting distractions, the stronger it gets.", "Cal Newport", "en"),
        Quote("Your future is created by what you do today, not tomorrow.", "Robert Kiyosaki", "en")
    )

    fun todayQuote(lang: String = "hi"): Quote {
        val filtered = QUOTES.filter { it.lang == lang }
        val pool = if (filtered.isNotEmpty()) filtered else QUOTES
        val dayIndex = (System.currentTimeMillis() / (24 * 3600 * 1000L)) % pool.size
        return pool[dayIndex.toInt()]
    }

    fun randomMotivation(lang: String = "hi"): Quote {
        val filtered = QUOTES.filter { it.lang == lang }
        val pool = if (filtered.isNotEmpty()) filtered else QUOTES
        return pool[Random.nextInt(pool.size)]
    }
}
