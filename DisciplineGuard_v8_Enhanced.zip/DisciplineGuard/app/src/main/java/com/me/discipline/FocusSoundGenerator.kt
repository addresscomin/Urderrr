package com.me.discipline

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.sin
import kotlin.random.Random

/**
 * Procedural Ambient Audio Synthesizer for Deep Focus & Study sessions.
 * Synthesizes White Noise, Gentle Rain, and Zen Focus Pulse directly on-device
 * using android.media.AudioTrack without any audio asset files.
 */
object FocusSoundGenerator {

    enum class SoundType { RAIN, WHITE_NOISE, ZEN_PULSE, NONE }

    @Volatile private var isPlaying = false
    @Volatile private var currentType = SoundType.NONE
    private var audioTrack: AudioTrack? = null
    private var playThread: Thread? = null

    fun isRunning(): Boolean = isPlaying
    fun getSoundType(): SoundType = currentType

    fun start(type: SoundType) {
        stop()
        if (type == SoundType.NONE) return
        currentType = type
        isPlaying = true

        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(sampleRate)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()

        playThread = thread(start = true, name = "FocusSoundSynth") {
            val chunk = ShortArray(1024)
            var phase = 0.0
            var filterState = 0.0
            var waveMod = 0.0

            while (isPlaying) {
                for (i in chunk.indices) {
                    when (currentType) {
                        SoundType.WHITE_NOISE -> {
                            val raw = (Random.nextFloat() * 2f - 1f) * 0.15f
                            chunk[i] = (raw * Short.MAX_VALUE).toInt().toShort()
                        }
                        SoundType.RAIN -> {
                            // Pink/Brown low-pass filtered noise with subtle amplitude swelling
                            waveMod += 0.0001
                            val swell = 0.6f + 0.4f * sin(waveMod).toFloat()
                            val white = Random.nextFloat() * 2f - 1f
                            filterState = (filterState * 0.94) + (white * 0.06)
                            val rain = (filterState * swell * 0.25).toFloat()
                            chunk[i] = (rain * Short.MAX_VALUE).toInt().toShort()
                        }
                        SoundType.ZEN_PULSE -> {
                            // Gentle 432 Hz harmonic tone modulated with 0.2 Hz breathing pulse
                            phase += 2.0 * Math.PI * 432.0 / sampleRate
                            waveMod += 2.0 * Math.PI * 0.15 / sampleRate
                            val pulse = 0.5 + 0.5 * sin(waveMod)
                            val sample = sin(phase) * pulse * 0.12
                            chunk[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                        }
                        SoundType.NONE -> {
                            chunk[i] = 0
                        }
                    }
                }
                try {
                    audioTrack?.write(chunk, 0, chunk.size)
                } catch (e: Exception) {
                    break
                }
            }
        }
    }

    fun stop() {
        isPlaying = false
        currentType = SoundType.NONE
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        } catch (e: Exception) {}
        audioTrack = null
        playThread = null
    }
}
