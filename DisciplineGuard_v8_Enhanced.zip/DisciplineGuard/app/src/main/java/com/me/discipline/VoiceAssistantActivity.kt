package com.me.discipline

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * Interactive Voice AI Assistant for DisciplineGuard Pro.
 * Features an animated pulsing voice orb, dynamic conversation bubbles,
 * real-time speech recognition, natural TTS, and one-tap suggestion chips.
 */
class VoiceAssistantActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var root: LinearLayout
    private lateinit var orb: VoiceOrbView
    private lateinit var statusText: TextView
    private lateinit var chatCol: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var inputEt: EditText

    private var speechRec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsLang = "hi"
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG
        val d = Ui.dp(this, 1)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#09090F"), Color.parseColor("#0F0F1E"), Color.parseColor("#09090F"))
            )
            setPadding(16 * d, 40 * d, 16 * d, 16 * d)
        }

        // Top Header
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = Ui.pill(this, "✕ Close", Ui.CARD_ELEVATED, Ui.LABEL) { finish() }
        val headerTitle = Ui.text(this, "Discipline Voice AI", 18f, Ui.LABEL, true).apply {
            gravity = Gravity.CENTER
        }
        topBar.addView(backBtn)
        topBar.addView(headerTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val langBadge = Ui.badge(this, "HI / EN / UR", Ui.CARD_ELEVATED, Ui.INDIGO_LIGHT)
        topBar.addView(langBadge)
        root.addView(topBar)

        // Animated Voice Orb
        val orbBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, 16 * d, 0, 8 * d)
        }
        orb = VoiceOrbView(this).apply {
            isClickable = true
            setOnClickListener { startListening() }
        }
        orbBox.addView(orb, LinearLayout.LayoutParams(160 * d, 160 * d))
        root.addView(orbBox)

        // Status indicator
        statusText = Ui.text(this, "Tap the orb or speak...", 13f, Ui.INDIGO_LIGHT).apply {
            gravity = Gravity.CENTER
            setPadding(0, 4 * d, 0, 10 * d)
        }
        root.addView(statusText)

        // Suggestion Chips (Horizontal Scroll)
        val hsv = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chipsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = listOf(
            "⏱️ Screen time?",
            "🕌 Next prayer?",
            "📋 Active task?",
            "⚡ Discipline score?",
            "🎯 Focus mode",
            "💡 Motivate me!"
        )
        for (chip in chips) {
            val chipView = TextView(this).apply {
                text = chip
                textSize = 12f
                setTextColor(Ui.LABEL)
                background = Ui.rounded(Ui.CARD_ELEVATED, 16f * d, Ui.CARD_BORDER, 1 * d)
                setPadding(12 * d, 7 * d, 12 * d, 7 * d)
                isClickable = true
                setOnClickListener { sendQuery(chip.substring(3).trim()) }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                rightMargin = 8 * d
            }
            chipsRow.addView(chipView, lp)
        }
        hsv.addView(chipsRow)
        root.addView(hsv, Ui.lp(this, 6, 8))

        // Chat Message Log
        chatCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4 * d, 8 * d, 4 * d, 8 * d)
        }
        chatScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(chatCol)
        }
        root.addView(chatScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // Bottom Input Row
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8 * d, 0, 0)
        }
        inputEt = EditText(this).apply {
            hint = "Ask anything about your discipline..."
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.LABEL)
            textSize = 14f
            background = Ui.rounded(Ui.CARD_ELEVATED, 14f * d, Ui.CARD_BORDER, 1 * d)
            setPadding(14 * d, 10 * d, 14 * d, 10 * d)
        }
        val sendBtn = Ui.pill(this, "Send", Ui.INDIGO, Color.WHITE) {
            val t = inputEt.text.toString().trim()
            if (t.isNotEmpty()) {
                inputEt.setText("")
                sendQuery(t)
            }
        }
        inputRow.addView(inputEt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        inputRow.addView(sendBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = 8 * d
        })
        root.addView(inputRow)

        setContentView(root)

        // Initialize TTS
        tts = TextToSpeech(this, this)

        // Add initial greeting bubble
        addMessageBubble("🤖 Focus Guard AI", "नमस्ते! मैं आपका डिसिप्लिन वॉइस असिस्टेंट हूँ। आप स्क्रीन टाइम, नमाज़, रूटीन या मोटिवेशन के बारे में कभी भी पूछ सकते हैं।", false)

        // Auto start listening on open
        h.postDelayed({ startListening() }, 500)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        val locales = listOf(Locale("hi", "IN"), Locale("ur", "PK"), Locale.ENGLISH)
        for (loc in locales) {
            if (t.setLanguage(loc) >= TextToSpeech.LANG_AVAILABLE) {
                ttsLang = loc.language
                break
            }
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {
                h.post { orb.setState(VoiceOrbView.State.SPEAKING); statusText.text = "Speaking..." }
            }
            override fun onDone(id: String?) {
                h.post { orb.setState(VoiceOrbView.State.IDLE); statusText.text = "Tap the orb to speak..." }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                h.post { orb.setState(VoiceOrbView.State.IDLE); statusText.text = "Tap the orb to speak..." }
            }
        })
        ttsReady = true
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
            return
        }

        stopSpeaking()
        destroyRecognizer()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition unavailable on this device", Toast.LENGTH_SHORT).show()
            return
        }

        orb.setState(VoiceOrbView.State.LISTENING)
        statusText.text = "Listening... Speak now"

        speechRec = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        else
            SpeechRecognizer.createSpeechRecognizer(this)

        speechRec?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {
                orb.setState(VoiceOrbView.State.LISTENING)
            }
            override fun onRmsChanged(v: Float) {
                orb.setRms(v)
            }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {
                orb.setState(VoiceOrbView.State.THINKING)
                statusText.text = "Processing..."
            }
            override fun onError(error: Int) {
                orb.setState(VoiceOrbView.State.IDLE)
                statusText.text = "Tap orb to speak again"
            }
            override fun onResults(results: Bundle?) {
                orb.setState(VoiceOrbView.State.THINKING)
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spoken = matches[0]
                    sendQuery(spoken)
                } else {
                    orb.setState(VoiceOrbView.State.IDLE)
                    statusText.text = "Could not hear clearly. Tap orb to retry."
                }
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Config.VOICE_LANG)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechRec?.startListening(i)
        } catch (e: Exception) {
            orb.setState(VoiceOrbView.State.IDLE)
            statusText.text = "Tap orb to start"
        }
    }

    private fun sendQuery(query: String) {
        addMessageBubble("👤 You", query, true)
        orb.setState(VoiceOrbView.State.THINKING)
        statusText.text = "Thinking..."

        h.postDelayed({
            val resp = VoiceAssistantBrain.processQuery(this, query, ttsLang)
            addMessageBubble("🤖 Assistant", resp.displayText, false)
            speakResponse(resp.spokenText)

            if (resp.actionType == "FOCUS_START") {
                startActivity(Intent(this, FocusModeActivity::class.java))
            }
        }, 300)
    }

    private fun speakResponse(text: String) {
        if (!ttsReady || tts == null) return
        stopSpeaking()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voice_ai_reply")
    }

    private fun stopSpeaking() {
        try { tts?.stop() } catch (e: Exception) {}
    }

    private fun destroyRecognizer() {
        try { speechRec?.cancel() } catch (e: Exception) {}
        try { speechRec?.destroy() } catch (e: Exception) {}
        speechRec = null
    }

    private fun addMessageBubble(sender: String, message: String, isUser: Boolean) {
        val d = Ui.dp(this, 1)
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bgCol = if (isUser) Ui.INDIGO else Ui.CARD_ELEVATED
            background = Ui.rounded(bgCol, 16f * d, if (isUser) 0 else Ui.CARD_BORDER, if (isUser) 0 else 1 * d)
            setPadding(14 * d, 10 * d, 14 * d, 10 * d)
        }

        bubble.addView(Ui.text(this, sender, 11f, if (isUser) Color.parseColor("#E0E7FF") else Ui.INDIGO_LIGHT, true))
        bubble.addView(Ui.text(this, message, 14f, Color.WHITE).apply {
            setPadding(0, 3 * d, 0, 0)
            setLineSpacing(0f, 1.15f)
        })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (isUser) Gravity.END else Gravity.START
            setPadding(0, 4 * d, 0, 4 * d)
        }
        val lp = LinearLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.82f).toInt(),
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        row.addView(bubble, lp)
        chatCol.addView(row)

        h.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        destroyRecognizer()
        stopSpeaking()
        try { tts?.shutdown() } catch (e: Exception) {}
        super.onDestroy()
    }
}
