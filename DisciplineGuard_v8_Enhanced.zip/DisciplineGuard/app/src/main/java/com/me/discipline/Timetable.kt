package com.me.discipline

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * TIMETABLE MODULE (alag store "timetable"): roz ka routine.
 * Har task ka waqt (start-end), optional live-photo saboot, aur saza (minute).
 * Time nikal gaya aur task done nahi = phone lock (saza), har agli miss par +15 min.
 * Activate ke baad: naya task jod sakte ho, par purana badal/hata nahi sakte.
 */
object Timetable {
    data class Task(
        val id: String, val title: String, val start: Int, val end: Int,
        val proof: Boolean, val punishMin: Int, val created: Long
    )

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("timetable", Context.MODE_PRIVATE)

    // ---------- storage ----------
    fun all(c: Context): List<Task> {
        val out = ArrayList<Task>()
        try {
            val a = JSONArray(sp(c).getString("tasks", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Task(
                    o.getString("id"), o.getString("t"), o.getInt("s"), o.getInt("e"),
                    o.optBoolean("p", false), o.optInt("pm", 30), o.optLong("c", 0L)
                ))
            }
        } catch (e: Exception) {}
        return out.sortedBy { it.start }
    }

    private fun save(c: Context, list: List<Task>) {
        val a = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id); o.put("t", t.title); o.put("s", t.start); o.put("e", t.end)
            o.put("p", t.proof); o.put("pm", t.punishMin); o.put("c", t.created)
            a.put(o)
        }
        sp(c).edit().putString("tasks", a.toString()).apply()
    }

    fun find(c: Context, id: String): Task? = all(c).firstOrNull { it.id == id }

    /** null = add ho gaya, warna error message. */
    fun add(c: Context, title: String, start: Int, end: Int, proof: Boolean, punish: Int): String? {
        if (title.isBlank()) return "Enter a task name."
        if (end - start < 10) return "A task slot must be at least 10 minutes."
        val sSleep = Prefs.sleepStartMin(c)
        val eSleep = Prefs.sleepEndMin(c)
        if (start < eSleep || end > sSleep)
            return "A task must fall outside sleep time (${TimeUtil.fmtMin(sSleep)} - ${TimeUtil.fmtMin(eSleep)})."
        val cur = all(c)
        if (cur.size >= 30) return "Maximum 30 tasks."
        if (cur.any { start < it.end && it.start < end }) return "This slot overlaps another task."
        val now = System.currentTimeMillis()
        save(c, cur + Task("t$now", title.trim(), start, end, proof, punish.coerceIn(10, 240), now))
        return null
    }

    /** Activate se pehle hi hata sakte ho. */
    fun remove(c: Context, id: String): Boolean {
        if (Prefs.armed(c)) return false
        save(c, all(c).filter { it.id != id })
        return true
    }

    // ---------- daily state ----------
    fun done(c: Context, day: String, id: String) = sp(c).getBoolean("done_${day}_$id", false)
    fun setDone(c: Context, day: String, id: String) { sp(c).edit().putBoolean("done_${day}_$id", true).apply() }
    fun missed(c: Context, day: String, id: String) = sp(c).getBoolean("miss_${day}_$id", false)
    private fun setMissed(c: Context, day: String, id: String) { sp(c).edit().putBoolean("miss_${day}_$id", true).apply() }
    private fun bumpMissed(c: Context, day: String): Int {
        val n = sp(c).getInt("mc_$day", 0) + 1
        sp(c).edit().putInt("mc_$day", n).apply()
        return n
    }

    fun isOpen(t: Task, now: Long): Boolean {
        val base = TimeUtil.midnight(0)
        return now >= base + t.start * 60000L && now < base + t.end * 60000L
    }

    /** Abhi jinka waqt chal raha hai aur jo abhi tak done nahi. */
    fun active(c: Context, now: Long = System.currentTimeMillis()): List<Task> {
        val day = Prefs.dayKey(now)
        return all(c).filter { isOpen(it, now) && !done(c, day, it.id) }
    }

    /** UI ke liye aaj ka status. */
    fun status(c: Context, t: Task, now: Long = System.currentTimeMillis()): String {
        val day = Prefs.dayKey(now)
        val base = TimeUtil.midnight(0)
        return when {
            done(c, day, t.id) -> "done"
            missed(c, day, t.id) -> "missed"
            now >= base + t.end * 60000L -> if (Prefs.armed(c) && t.created < base + t.start * 60000L) "missed" else "over"
            now >= base + t.start * 60000L -> "open"
            else -> "upcoming"
        }
    }

    /** Task poora karne ka tareeka: photo wala to camera, warna seedha done. */
    fun confirm(a: Activity, t: Task) {
        if (!isOpen(t, System.currentTimeMillis())) {
            Toast.makeText(a, "It is not time for this task yet.", Toast.LENGTH_LONG).show(); return
        }
        if (t.proof) {
            a.startActivity(Intent(a, ProofActivity::class.java).putExtra("taskId", t.id))
        } else {
            setDone(a, Prefs.dayKey(), t.id)
            Toast.makeText(a, "${t.title} done ✅", Toast.LENGTH_LONG).show()
        }
    }

    fun notifyStart(c: Context, id: String) {
        val t = find(c, id) ?: return
        if (done(c, Prefs.dayKey(), t.id)) return
        Notif.alert(
            c, 2000 + (t.id.hashCode() and 0xfff),
            "⏰ ${t.title}",
            "Complete it between ${TimeUtil.fmtMin(t.start)} and ${TimeUtil.fmtMin(t.end)}. Otherwise the phone locks for ${t.punishMin} min."
        )
    }

    // ---------- punishment ----------
    /** Waqt nikal gaya aur task done nahi = saza. Pehli miss: punishMin, har agli miss us din +15 min. */
    fun sweep(c: Context) {
        if (!Prefs.armed(c)) return
        val now = System.currentTimeMillis()
        val tasks = all(c)
        for (off in -1..0) {
            val base = TimeUtil.midnight(off)
            val day = Prefs.dayKey(base)
            for (t in tasks) {
                val s = base + t.start * 60000L
                val e = base + t.end * 60000L
                if (now < e) continue
                if (t.created > s || Prefs.armedAt(c) > s) continue   // task/guard baad me bana to saza nahi
                if (done(c, day, t.id) || missed(c, day, t.id)) continue
                setMissed(c, day, t.id)
                val n = bumpMissed(c, day)
                val minutes = t.punishMin + 15 * (n - 1)
                val until = e + minutes * 60000L
                Prefs.extendLock(c, until, "task")
                if (until > now) {
                    VoiceService.speak(c, "task", 0, (until - now) / 60000L)
                    Notif.alert(c, 3000 + (t.id.hashCode() and 0xfff), "❌ Missed: ${t.title}",
                        "Penalty: phone locked for ${(until - now) / 60000L} min.")
                }
            }
        }
    }
}
