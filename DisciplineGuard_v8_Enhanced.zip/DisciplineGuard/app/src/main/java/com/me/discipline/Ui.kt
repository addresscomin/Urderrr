package com.me.discipline

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Ultra-Modern Dark Design System for DisciplineGuard Pro:
 * Deep obsidian surfaces, glassmorphic cards, neon indigo/emerald accents,
 * stat tiles, glowing badges, and crisp typography.
 */
object Ui {
    // Primary Accents
    val INDIGO = Color.parseColor("#6366F1")
    val INDIGO_LIGHT = Color.parseColor("#818CF8")
    val BLUE = Color.parseColor("#38BDF8")
    val GREEN = Color.parseColor("#10B981")
    val GREEN_LIGHT = Color.parseColor("#34D399")
    val AMBER = Color.parseColor("#F59E0B")
    val RED = Color.parseColor("#EF4444")
    val PURPLE = Color.parseColor("#A855F7")

    // Surfaces & Backgrounds
    val BG = Color.parseColor("#09090F")
    val BG_SECONDARY = Color.parseColor("#0F0F1A")
    val CARD = Color.parseColor("#141422")
    val CARD_ELEVATED = Color.parseColor("#1C1C2E")
    val CARD_BORDER = Color.parseColor("#272740")
    val SEP = Color.parseColor("#222238")

    // Typography Colors
    val LABEL = Color.parseColor("#F8FAFC")
    val SUB = Color.parseColor("#94A3B8")
    val MUTED = Color.parseColor("#64748B")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusPx: Float, strokeColor: Int = 0, strokeWidthPx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
            if (strokeWidthPx > 0) setStroke(strokeWidthPx, strokeColor)
        }

    fun gradient(startColor: Int, endColor: Int, radiusPx: Float, orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TL_BR): GradientDrawable =
        GradientDrawable(orientation, intArrayOf(startColor, endColor)).apply {
            cornerRadius = radiusPx
        }

    fun text(c: Context, t: String, sp: Float, color: Int = LABEL, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = t
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun lp(c: Context, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(c, top)
            bottomMargin = dp(c, bottom)
        }

    fun card(c: Context, elevated: Boolean = false): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            val bgCol = if (elevated) CARD_ELEVATED else CARD
            background = rounded(bgCol, dp(c, 22).toFloat(), CARD_BORDER, dp(c, 1))
            setPadding(dp(c, 20), dp(c, 16), dp(c, 20), dp(c, 16))
        }

    fun cardIn(c: Context, parent: LinearLayout, top: Int = 10, elevated: Boolean = false): LinearLayout {
        val k = card(c, elevated)
        parent.addView(k, lp(c, top))
        return k
    }

    fun section(c: Context, parent: LinearLayout, t: String, top: Int = 24) {
        val tv = text(c, t.uppercase(), 12f, INDIGO_LIGHT, true).apply {
            setPadding(dp(c, 6), 0, 0, dp(c, 6))
            letterSpacing = 0.12f
        }
        parent.addView(tv, lp(c, top))
    }

    fun pill(c: Context, t: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = t
            textSize = 15f
            setTextColor(fg)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(bg, dp(c, 14).toFloat())
            setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun gradientButton(c: Context, t: String, startCol: Int, endCol: Int, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = t
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = gradient(startCol, endCol, dp(c, 16).toFloat())
            setPadding(dp(c, 18), dp(c, 14), dp(c, 18), dp(c, 14))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun badge(c: Context, t: String, bg: Int, fg: Int): TextView =
        TextView(c).apply {
            text = t
            textSize = 11f
            setTextColor(fg)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(bg, dp(c, 8).toFloat())
            setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4))
        }

    fun row(
        c: Context,
        parent: LinearLayout,
        left: String,
        right: String,
        rightColor: Int = SUB,
        subLeft: String? = null,
        onClick: (() -> Unit)? = null
    ) {
        val r = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(c, 12), 0, dp(c, 12))
            if (onClick != null) {
                isClickable = true
                setOnClickListener { onClick() }
            }
        }

        val leftBox = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
        }
        leftBox.addView(text(c, left, 15f, LABEL, true))
        if (!subLeft.isNullOrEmpty()) {
            leftBox.addView(text(c, subLeft, 12f, MUTED))
        }
        r.addView(leftBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val rightTv = text(c, right, 14f, rightColor, true)
        r.addView(rightTv)

        parent.addView(r)
        parent.addView(View(c).apply { setBackgroundColor(SEP) }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
    }

    fun field(c: Context, parent: LinearLayout, label: String, value: String, decimal: Boolean = false): EditText {
        parent.addView(text(c, label, 12f, SUB).apply { setPadding(0, dp(c, 10), 0, dp(c, 4)) })
        val e = EditText(c).apply {
            setTextColor(LABEL)
            setText(value)
            textSize = 15f
            background = rounded(CARD_ELEVATED, dp(c, 10).toFloat(), CARD_BORDER, dp(c, 1))
            setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
            inputType = if (decimal)
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            else
                InputType.TYPE_CLASS_NUMBER
        }
        parent.addView(e, lp(c, 0, 8))
        return e
    }

    /** Modern Action Card with icon, title, description, and accent indicator. */
    fun actionCard(
        c: Context,
        parent: LinearLayout,
        iconEmoji: String,
        title: String,
        desc: String,
        accentColor: Int,
        onClick: () -> Unit
    ): LinearLayout {
        val k = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, dp(c, 18).toFloat(), CARD_BORDER, dp(c, 1))
            setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16))
            isClickable = true
            setOnClickListener { onClick() }
        }

        // Icon Box
        val iconBox = LinearLayout(c).apply {
            gravity = Gravity.CENTER
            val alphaAccent = Color.argb(40, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            background = rounded(alphaAccent, dp(c, 14).toFloat())
            setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
        }
        iconBox.addView(text(c, iconEmoji, 22f))
        k.addView(iconBox)

        // Text Box
        val tb = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 14), 0, dp(c, 8), 0)
        }
        tb.addView(text(c, title, 16f, LABEL, true))
        tb.addView(text(c, desc, 12f, SUB).apply { setPadding(0, dp(c, 2), 0, 0) })
        k.addView(tb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        // Arrow
        k.addView(text(c, "›", 22f, MUTED, true))

        parent.addView(k, lp(c, 10))
        return k
    }
}
