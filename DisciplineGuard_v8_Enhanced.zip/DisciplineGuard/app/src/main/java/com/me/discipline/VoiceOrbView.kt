package com.me.discipline

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator

/**
 * Animated Voice AI Orb:
 * Features multi-ring ripples, a glowing core, and audio wave modulation.
 * Reacts to states: IDLE, LISTENING, THINKING, SPEAKING.
 */
class VoiceOrbView(context: Context) : View(context) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    private var currentState = State.IDLE
    private var pulse = 0f
    private var rotateAngle = 0f
    private var rmsLevel = 0f

    private val density = context.resources.displayMetrics.density

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800L
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
    }

    private val spinAnim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            rotateAngle = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        pulseAnim.start()
        spinAnim.start()
    }

    fun setState(state: State) {
        this.currentState = state
        when (state) {
            State.IDLE -> {
                pulseAnim.duration = 2000L
                spinAnim.duration = 7000L
            }
            State.LISTENING -> {
                pulseAnim.duration = 900L
                spinAnim.duration = 3000L
            }
            State.THINKING -> {
                pulseAnim.duration = 600L
                spinAnim.duration = 1500L
            }
            State.SPEAKING -> {
                pulseAnim.duration = 800L
                spinAnim.duration = 4000L
            }
        }
        invalidate()
    }

    fun setRms(rms: Float) {
        this.rmsLevel = (rms.coerceIn(0f, 10f) / 10f)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!pulseAnim.isRunning) pulseAnim.start()
        if (!spinAnim.isRunning) spinAnim.start()
    }

    override fun onDetachedFromWindow() {
        pulseAnim.cancel()
        spinAnim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val cx = w / 2f
        val cy = h / 2f
        val baseRadius = (minOf(w, h) * 0.28f) + (rmsLevel * 18f * density)

        val (primaryColor, glowColor) = when (currentState) {
            State.IDLE -> Pair(Color.parseColor("#6366F1"), Color.parseColor("#818CF8"))       // Indigo
            State.LISTENING -> Pair(Color.parseColor("#10B981"), Color.parseColor("#34D399"))  // Emerald Pulse
            State.THINKING -> Pair(Color.parseColor("#F59E0B"), Color.parseColor("#FBBF24"))   // Amber
            State.SPEAKING -> Pair(Color.parseColor("#38BDF8"), Color.parseColor("#818CF8"))   // Cyan / Sky
        }

        // Outer Aura
        val auraRadius = baseRadius * (1.5f + pulse * 0.35f)
        auraPaint.shader = RadialGradient(
            cx, cy, auraRadius,
            intArrayOf(
                Color.argb(70, Color.red(glowColor), Color.green(glowColor), Color.blue(glowColor)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0.4f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, auraRadius, auraPaint)

        // Middle Ripple Rings
        ringPaint.strokeWidth = 2.5f * density
        ringPaint.color = Color.argb(
            (60 + pulse * 60).toInt(),
            Color.red(primaryColor), Color.green(primaryColor), Color.blue(primaryColor)
        )
        canvas.drawCircle(cx, cy, baseRadius * (1.2f + pulse * 0.2f), ringPaint)

        ringPaint.strokeWidth = 1.5f * density
        ringPaint.color = Color.argb(
            (40 + (1f - pulse) * 40).toInt(),
            Color.red(glowColor), Color.green(glowColor), Color.blue(glowColor)
        )
        canvas.drawCircle(cx, cy, baseRadius * (1.4f + (1f - pulse) * 0.2f), ringPaint)

        // Core Sphere with radial depth
        val coreRadius = baseRadius * (0.95f + pulse * 0.1f)
        corePaint.shader = RadialGradient(
            cx - coreRadius * 0.3f, cy - coreRadius * 0.3f, coreRadius * 1.3f,
            intArrayOf(Color.WHITE, glowColor, primaryColor),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreRadius, corePaint)
    }
}
