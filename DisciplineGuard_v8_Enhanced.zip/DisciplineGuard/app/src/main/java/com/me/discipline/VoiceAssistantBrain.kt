package com.me.discipline

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Natural Language Processing (NLP) Engine for the Voice AI Assistant.
 * Understands Hindi, Urdu, Hinglish, and English queries and returns natural,
 * context-grounded spoken responses.
 */
object VoiceAssistantBrain {

    data class Response(
        val spokenText: String,
        val displayText: String,
        val actionType: String? = null, // "FOCUS_START", "TASK_DONE", "PRAYER_INFO", etc.
        val actionData: String? = null
    )

    fun processQuery(c: Context, rawQuery: String, preferredLang: String = "hi"): Response {
        val q = rawQuery.lowercase().trim()
        val now = System.currentTimeMillis()

        // 1. Greetings
        if (matches(q, listOf("salam", "assalam", "salaam", "hello", "hi ", "hey", "नमस्ते", "आदाब", "kaise ho", "how are you"))) {
            return when (preferredLang) {
                "ur" -> Response(
                    "وعلیکم السلام! میں آپ کا فوکس گارڈ وائس اسسٹنٹ ہوں۔ آج آپ کے کیا مقاصد ہیں؟",
                    "وعلیکم السلام! میں آپ کا فوکس گارڈ اسسٹنٹ ہوں۔ آپ اسکرین ٹائم، نماز، روٹین یا موٹیویشن پوچھ سکتے ہیں۔"
                )
                "en" -> Response(
                    "Hello! I am your Focus Guard AI Assistant. Ready to stay disciplined today? You can ask about screen time, prayers, tasks or motivation.",
                    "Hello! I am your Focus Guard AI Assistant. Ask about screen time, prayers, tasks, or motivation."
                )
                else -> Response(
                    "नमस्ते और अस्सलाम वालेकुम! मैं आपका डिसिप्लिन गार्ड वॉइस असिस्टेंट हूँ। आज आपको क्या चेक करना है?",
                    "नमस्ते! मैं आपका डिसिप्लिन गार्ड असिस्टेंट हूँ। आप स्क्रीन टाइम, नमाज़, रूटीन या मोटिवेशन पूछ सकते हैं।"
                )
            }
        }

        // 2. Who are you
        if (matches(q, listOf("who are you", "kaun ho", "kon ho", "tum kaun", "aap kaun", "what can you do", "kya kar sakte ho"))) {
            return Response(
                "मैं आपका पर्सनल डिसिप्लिन और फोकस कोच हूँ। मैं आपके स्क्रीन टाइम, नमाज़ के वक्त, डेली रूटीन और डिसिप्लिन स्कोर का पूरा ख्याल रखता हूँ ताकि आप अपने लक्ष्य हासिल कर सकें।",
                "🎙️ **Focus Guard AI Assistant**\n• स्क्रीन टाइम & लिमिट मॉनिटर\n• नमाज़ अलार्म & वक्त गाइड\n• डेली टाइमटेबल ट्रैकर\n• डीप फोकस पॉमोडोरो\n• डिसिप्लिन स्कोर & स्ट्रीक्स"
            )
        }

        // 3. Screen Time & Limit Queries
        if (matches(q, listOf("screen time", "kitna time", "time bacha", "time left", "phone limit", "kitna use", "used time", "kitna bacha", "remaining"))) {
            val limitMin = Prefs.dailyLimitMin(c)
            val usedMin = (Prefs.used(c) / 60000L).toInt()
            val leftMin = (limitMin - usedMin).coerceAtLeast(0)

            val speech = if (leftMin > 30) {
                "आज आपने $usedMin मिनट फोन इस्तेमाल किया है। आपकी $limitMin मिनट की लिमिट में से अभी $leftMin मिनट बाकी हैं। समझदारी से इस्तेमाल करें।"
            } else if (leftMin > 0) {
                "चेतावनी! आपके पास सिर्फ $leftMin मिनट का स्क्रीन टाइम बाकी है। जल्द ही जरूरी काम खत्म करके फोन रख दीजिए।"
            } else {
                "आज की आपकी पूरी फोन लिमिट खत्म हो चुकी है। अब फोन कॉल्स के अलावा लॉक रहेगा।"
            }

            return Response(
                speech,
                "⏱️ **स्क्रीन टाइम स्टेटस**\n• इस्तेमाल: $usedMin / $limitMin मिनट\n• बाकी: $leftMin मिनट\n• स्टेटस: ${if (leftMin > 30) "सुरक्षित" else "क्रिटिकल"}"
            )
        }

        // 4. Prayer & Namaz Queries
        if (matches(q, listOf("namaz", "prayer", "fajr", "zuhr", "asr", "maghrib", "isha", "salah", "salat", "अगली नमाज़", "नमाज"))) {
            if (!NamazPrefs.enabled(c)) {
                return Response(
                    "नमाज़ गार्ड मॉड्यूल अभी बंद है। आप सेटिंग्स से इसे चालू कर सकते हैं।",
                    "🕌 प्रेयर मॉड्यूल वर्तमान में डिसेबल्ड है।"
                )
            }
            val next = PrayerTimes.next(c, now)
            val day = Prefs.dayKey(now)
            var doneCount = 0
            for (i in 0..4) {
                if (NamazPrefs.done(c, day, i)) doneCount++
            }

            if (next != null) {
                val timeStr = SimpleDateFormat("hh:mm a", Locale.US).format(Date(next.start))
                val minLeft = ((next.start - now) / 60000L).coerceAtLeast(0)
                val prayerName = PrayerTimes.NAMES[next.idx]

                val speech = "अगली नमाज़ $prayerName की है, जो $timeStr पर होगी। इसमें अभी $minLeft मिनट बाकी हैं। आज आपने पांच में से $doneCount नमाज़ें मुकम्मल की हैं।"
                return Response(
                    speech,
                    "🕌 **नमाज़ स्टेटस**\n• अगली नमाज़: $prayerName ($timeStr)\n• बाकी वक्त: $minLeft मिनट\n• आज मुकम्मल: $doneCount / 5",
                    "PRAYER_INFO",
                    prayerName
                )
            } else {
                return Response(
                    "आज की सभी नमाज़ों का वक्त पूरा हो चुका है। आज आपने $doneCount नमाज़ें अदा की हैं। माशा अल्लाह।",
                    "🕌 आज की नमाज़ें: $doneCount / 5 पूर्ण"
                )
            }
        }

        // 5. Timetable & Task Status or Completion
        if (matches(q, listOf("task done", "task ho gaya", "task complete", "maine task kar liya", "mark done", "टास्क हो गया", "काम हो गया"))) {
            val activeTasks = Timetable.active(c, now)
            if (activeTasks.isNotEmpty()) {
                val t = activeTasks.first()
                val day = Prefs.dayKey(now)
                Timetable.setDone(c, day, t.id)
                VoiceService.speak(c, "done", 0, 0)
                return Response(
                    "बहुत खूब! आपका टास्क '${t.title}' कम्पलीट मार्क कर दिया गया है। अपनी रूटीन इसी तरह बनाए रखें।",
                    "✅ **टास्क मार्क डन**: ${t.title}\nशानदार! रूटीन कायम रखें।",
                    "TASK_DONE",
                    t.id
                )
            } else {
                return Response(
                    "इस वक्त कोई एक्टिव टास्क नहीं चल रहा है जिसे मार्क किया जा सके। आप अपना टाइमटेबल चेक कर सकते हैं।",
                    "ℹ️ इस समय कोई रनिंग टास्क नहीं है।"
                )
            }
        }

        if (matches(q, listOf("task", "routine", "timetable", "schedule", "काम", "रूटीन", "शेड्यूल"))) {
            val active = Timetable.active(c, now)
            val all = Timetable.all(c)
            if (active.isNotEmpty()) {
                val t = active.first()
                return Response(
                    "अभी आपका एक्टिव टास्क '${t.title}' चल रहा है। यह ${TimeUtil.fmtMin(t.end)} तक चलेगा। काम पूरा होने पर डन मार्क करें।",
                    "📋 **रनिंग टास्क**: ${t.title}\n• स्लॉट: ${TimeUtil.fmtMin(t.start)} - ${TimeUtil.fmtMin(t.end)}\n• पेनाल्टी: ${t.punishMin} मिनट"
                )
            } else if (all.isNotEmpty()) {
                return Response(
                    "आज आपके टाइमटेबल में कुल ${all.size} टास्क्स हैं। अपने अगले शेड्यूल के लिए तैयार रहें।",
                    "📋 कुल ${all.size} टास्क्स शेड्यूल्ड हैं। डैशबोर्ड पर टाइमटेबल देखें।"
                )
            } else {
                return Response(
                    "आपने अभी तक कोई डेली टास्क नहीं जोड़ा है। टाइमटेबल स्क्रीन में जाकर अपनी पढ़ाई या काम का शेड्यूल बनाएं।",
                    "📋 कोई टास्क नहीं मिला। टाइमटेबल मेन्यू से टास्क जोड़ें।"
                )
            }
        }

        // 6. Motivation & Quotes
        if (matches(q, listOf("motivate", "motivation", "quote", "प्रेरणा", "शायरी", "advice", "सलाह", "मन नहीं लग रहा", "distract"))) {
            val qObj = Quotes.randomMotivation(preferredLang)
            return Response(
                "${qObj.text} — यह सीख ${qObj.author} की है। हिम्मत मत हारिए और अपने लक्ष्य पर टिके रहिए।",
                "💡 **आज की प्रेरणा**\n\"${qObj.text}\"\n— *${qObj.author}*"
            )
        }

        // 7. Discipline Score & Streak
        if (matches(q, listOf("score", "streak", "discipline", "rank", "performance", "स्कोर", "स्ट्रीक", "मेरी प्रोग्रेस"))) {
            val score = Analytics.calculateTodayScore(c)
            val streak = Analytics.getStreakDays(c)
            val speech = "आज आपका डिसिप्लिन स्कोर $score प्रतिशत है, और आपकी $streak दिन की लगातार स्ट्रीक चल रही है। ${if (score >= 80) "आप बेहतरीन काम कर रहे हैं!" else "थोड़ी और मेहनत से आप इसे 90 प्लस ले जा सकते हैं।"}"
            return Response(
                speech,
                "⚡ **डिसिप्लिन एनालिटिक्स**\n• आज का स्कोर: $score%\n• एक्टिव स्ट्रीक: $streak दिन 🔥\n• रेटिंग: ${if (score >= 80) "एक्सीलेंट 🌟" else "इम्प्रूवमेंट जरूरी 📈"}"
            )
        }

        // 8. Focus Mode
        if (matches(q, listOf("focus", "study", "pomodoro", "फोकस", "पढ़ाई", "काम शुरू", "deep work"))) {
            return Response(
                "डीप फोकस मोड तैयार है। क्या आप 25 मिनट का फोकस सेशन शुरू करना चाहते हैं? मैं आपके लिए बैकग्राउंड में रिलैक्सिंग साउंड भी चला सकता हूँ।",
                "🎯 **डीप फोकस मोड**\nडैशबोर्ड से 'डीप फोकस टाइमर' खोलें और 25m / 45m सेशन शुरू करें।",
                "FOCUS_START"
            )
        }

        // 9. Sleep / Raat ka waqt
        if (matches(q, listOf("sleep", "sona", "bedtime", "raat", "सोना", "नींद", "स्लीप"))) {
            return Response(
                "स्लीप मोड रात ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} से सुबह ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)} तक रहेगा। इस दौरान सिर्फ फोन कॉल्स काम करेंगी ताकि आप अच्छी नींद ले सकें।",
                "🌙 **स्लीप मोड शेड्यूल**\n• स्टार्ट: ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)}\n• एन्ड: ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)}\n(सभी ऐप्स लॉक रहेंगे)"
            )
        }

        // Fallback Intelligent Response
        val fallbackQuote = Quotes.randomMotivation(preferredLang)
        return Response(
            "मैंने सुना: $rawQuery. आप मुझसे स्क्रीन टाइम, अगली नमाज़, टास्क या मोटिवेशन के बारे में पूछ सकते हैं। याद रखें: ${fallbackQuote.text}",
            "🤖 **असिस्टेंट गाइड**\nआप पूछ सकते हैं:\n• \"कितना स्क्रीन टाइम बचा है?\"\n• \"अगली नमाज़ कब है?\"\n• \"मेरा टास्क मार्क करो\"\n• \"मुझे मोटिवेट करो\"\n• \"डिसिप्लिन स्कोर क्या है?\""
        )
    }

    private fun matches(query: String, keywords: List<String>): Boolean {
        return keywords.any { query.contains(it.lowercase()) }
    }
}
