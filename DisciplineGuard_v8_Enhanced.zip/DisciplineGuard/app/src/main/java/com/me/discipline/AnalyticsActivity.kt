package com.me.discipline

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Discipline Analytics & Consistency Dashboard:
 * Visualizes 7-day performance, daily discipline score, active streak,
 * and module-by-module breakdown.
 */
class AnalyticsActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG
        val d = Ui.dp(this, 1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.BG
            setPadding(18 * d, 44 * d, 18 * d, 40 * d)
        }

        // Top bar
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = Ui.pill(this, "✕ Back", Ui.CARD_ELEVATED, Ui.LABEL) { finish() }
        val title = Ui.text(this, "Discipline Analytics", 18f, Ui.LABEL, true).apply {
            gravity = Gravity.CENTER
        }
        val streakDays = Analytics.getStreakDays(this)
        val streakBadge = Ui.badge(this, "🔥 $streakDays DAYS STREAK", Ui.CARD_ELEVATED, Ui.AMBER)
        topBar.addView(backBtn)
        topBar.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(streakBadge)
        col.addView(topBar, Ui.lp(this))

        val todayScore = Analytics.calculateTodayScore(this)
        val tier = when {
            todayScore >= 85 -> Pair("Elite Discipline 🏆", Ui.GREEN)
            todayScore >= 70 -> Pair("Strong Focus ⚡", Ui.INDIGO_LIGHT)
            todayScore >= 50 -> Pair("Moderate 📈", Ui.AMBER)
            else -> Pair("Needs Immediate Focus ⚠️", Ui.RED)
        }

        // Hero Score Card
        val hero = Ui.card(this, true)
        hero.addView(Ui.text(this, "TODAY'S DISCIPLINE SCORE", 11f, Ui.INDIGO_LIGHT, true).apply {
            letterSpacing = 0.15f
        })
        val scoreRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 4 * d, 0, 4 * d)
        }
        scoreRow.addView(Ui.text(this, "$todayScore", 56f, Color.WHITE, true))
        scoreRow.addView(Ui.text(this, " / 100", 22f, Ui.MUTED).apply {
            setPadding(4 * d, 14 * d, 0, 0)
        })
        val tierBadge = Ui.badge(this, tier.first, Ui.CARD, tier.second)
        scoreRow.addView(tierBadge, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = 14 * d
        })
        hero.addView(scoreRow)
        hero.addView(Ui.text(this,
            "Your score is calculated based on screen time limits, on-time prayers, timetable routines, and verbal honesty.",
            12f, Ui.SUB).apply { setPadding(0, 4 * d, 0, 4 * d) })
        col.addView(hero, Ui.lp(this, 14))

        // 7-Day Performance Chart
        Ui.section(this, col, "7-Day Consistency Trend")
        val chartCard = Ui.card(this)
        val chart = BarChartView(this)
        val pastWeek = Analytics.getPastWeek(this)
        val chartData = pastWeek.map {
            BarChartView.BarData(it.dayLabel, it.score.toFloat(), 100f, it.dayKey == Prefs.dayKey())
        }
        chart.setData(chartData)
        chartCard.addView(chart, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 180 * d))
        col.addView(chartCard, Ui.lp(this, 10))

        // Module-by-Module Breakdown
        Ui.section(this, col, "Today's Module Breakdown")
        val bc = Ui.card(this)

        val usedMin = Prefs.used(this) / 60000L
        val limitMin = Prefs.dailyLimitMin(this)
        Ui.row(this, bc, "Screen Time Limit", "$usedMin / $limitMin min", if (usedMin <= limitMin) Ui.GREEN else Ui.RED, "Max 30 pts")

        if (NamazPrefs.enabled(this)) {
            var prayersDone = 0
            val dayKey = Prefs.dayKey()
            for (i in 0..4) {
                if (NamazPrefs.done(this, dayKey, i)) prayersDone++
            }
            Ui.row(this, bc, "Prayer Guard", "$prayersDone / 5 prayers done", if (prayersDone >= 4) Ui.GREEN else Ui.AMBER, "Max 30 pts")
        }

        val tasks = Timetable.all(this)
        var tasksDone = 0
        val dayKey = Prefs.dayKey()
        for (t in tasks) {
            if (Timetable.done(this, dayKey, t.id)) tasksDone++
        }
        Ui.row(this, bc, "Daily Timetable", "$tasksDone / ${tasks.size} tasks done", if (tasksDone == tasks.size && tasks.isNotEmpty()) Ui.GREEN else Ui.SUB, "Max 30 pts")

        val lies = Prefs.int(this, "lie_" + Prefs.dayKey(), 0)
        Ui.row(this, bc, "Voice Integrity", if (lies == 0) "Clean (0 Flags) ✅" else "$lies Flag(s) ⚠️", if (lies == 0) Ui.GREEN else Ui.RED, "Max 10 pts")

        col.addView(bc, Ui.lp(this, 10))

        // Discipline Philosophy Card
        Ui.section(this, col, "Consistency Tips")
        val tipCard = Ui.card(this)
        tipCard.addView(Ui.text(this,
            "• Keep phone usage below 80% of daily limit for full screen time points.\n" +
            "• Submit live camera proof for prayers and routines on time.\n" +
            "• Maintain a 7-day streak to unlock high focus habit formation.\n" +
            "• Use the Voice AI Assistant regularly to stay accountable.",
            13f, Ui.LABEL).apply {
            setPadding(0, 6 * d, 0, 6 * d)
            setLineSpacing(0f, 1.2f)
        })
        col.addView(tipCard, Ui.lp(this, 10))

        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        }
        setContentView(sv)
    }
}
