package com.me.discipline

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Modern circular progress gauge for Screen Time / Discipline limit.
 * Smoothly animated with breathing glow and rounded caps.
 */
class CircleProgressView(context: Context) : View(context) {

    private var progress: Float = 0f
    private var max: Float = 180f
    private var animatedSweep: Float = 0f

    private val density = context.resources.displayMetrics.density
    private val strokeW = 12f * density

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeW
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#1A1A2E")
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeW
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private var animator: ValueAnimator? = null

    fun setProgress(current: Float, total: Float, animate: Boolean = true) {
        this.progress = current.coerceAtLeast(0f)
        this.max = total.coerceAtLeast(1f)
        val targetSweep = (progress / max).coerceIn(0f, 1f) * 360f

        animator?.cancel()
        if (animate) {
            animator = ValueAnimator.ofFloat(animatedSweep, targetSweep).apply {
                duration = 900L
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    animatedSweep = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            animatedSweep = targetSweep
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val cx = w / 2f
        val cy = h / 2f
        val radius = (minOf(w, h) - strokeW * 2.5f) / 2f

        // Progress color gradient (Green -> Amber -> Red as limit approaches)
        val fraction = (animatedSweep / 360f).coerceIn(0f, 1f)
        val color = when {
            fraction > 0.9f -> Color.parseColor("#EF4444") // Red alert
            fraction > 0.7f -> Color.parseColor("#F59E0B") // Amber warning
            else -> Color.parseColor("#10B981")           // Emerald good
        }
        progressPaint.color = color

        // Background subtle glow
        glowPaint.shader = RadialGradient(
            cx, cy, radius * 1.15f,
            intArrayOf(Color.argb(35, Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT),
            floatArrayOf(0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 1.15f, glowPaint)

        // Background full ring
        canvas.drawCircle(cx, cy, radius, bgPaint)

        // Active progress arc (starting from top, -90 degrees)
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        if (animatedSweep > 0f) {
            canvas.drawArc(rect, -90f, animatedSweep, false, progressPaint)
        }
    }
}
