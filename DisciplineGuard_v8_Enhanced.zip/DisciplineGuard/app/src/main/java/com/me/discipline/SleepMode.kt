package com.me.discipline

import android.content.Context
import java.util.Calendar

/** Sleep lock: poora phone band (sirf call/emergency), lock screen. */
object SleepMode {
    fun active(c: Context? = null, now: Long = System.currentTimeMillis()): Boolean {
        val m = TimeUtil.minutesOfDay(now)
        val s = if (c != null) Prefs.sleepStartMin(c) else Config.SLEEP_START_MIN
        val e = if (c != null) Prefs.sleepEndMin(c) else Config.SLEEP_END_MIN
        return if (s > e) (m >= s || m < e) else (m in s until e)
    }

    /** Agli baar sleep kab khatam hoga. */
    fun endsAt(c: Context? = null, now: Long = System.currentTimeMillis()): Long {
        val e = if (c != null) Prefs.sleepEndMin(c) else Config.SLEEP_END_MIN
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, e / 60)
        cal.set(Calendar.MINUTE, e % 60)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
}
