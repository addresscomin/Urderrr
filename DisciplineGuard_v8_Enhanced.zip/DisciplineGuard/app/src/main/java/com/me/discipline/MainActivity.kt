package com.me.discipline

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Focus Guard Pro v8.0 Dashboard:
 * Ultra-modern dark UI featuring live circular screen time gauge,
 * 4-tile quick stats bar, AI Voice Assistant shortcut, Deep Focus mode,
 * Prayer Guard, Timetable routines, Analytics, and strict device protection.
 */
class MainActivity : Activity() {

    private lateinit var col: LinearLayout
    private var currentQuote = Quotes.todayQuote("hi")
    private val h = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            if (Prefs.armed(this@MainActivity) && Policy.ownScreenReason(this@MainActivity) != null) {
                BlockActivity.show(this@MainActivity, "locked")
            }
            h.postDelayed(this, 3000)
        }
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked")
            finish()
            return
        }
        Hardening.apply(this)
        VoiceListenerService.start(this)
        render()
        h.post(ticker)
    }

    override fun onPause() {
        h.removeCallbacks(ticker)
        super.onPause()
    }

    private fun d(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun accOn(): Boolean {
        val flat = ComponentName(this, BlockerAccessibilityService::class.java).flattenToString()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(flat)
    }

    private fun isHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == packageName
    }

    private fun open(a: String, pkg: Boolean = true) {
        try {
            val i = Intent(a)
            if (pkg) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) { toast("Could not open that screen") }
    }

    private fun perm(parent: LinearLayout, name: String, ok: Boolean, action: () -> Unit) {
        Ui.row(this, parent, name, if (ok) "Allowed ✅" else "Allow ➔", if (ok) Ui.GREEN else Ui.INDIGO_LIGHT) {
            if (!ok) action()
        }
    }

    private fun render() {
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(d(18), d(44), d(18), d(40))
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(col)
        }
        setContentView(sv)

        val armed = Prefs.armed(this)
        val owner = Hardening.isOwner(this)
        val usedMin = (Prefs.used(this) / 60000L).toInt()
        val limitMin = Prefs.dailyLimitMin(this)
        val remainingMin = (limitMin - usedMin).coerceAtLeast(0)
        val score = Analytics.calculateTodayScore(this)
        val streak = Analytics.getStreakDays(this)

        // 1. Sleek Header Bar
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(Ui.text(this, "Focus Guard Pro", 26f, Ui.LABEL, true))
        titleBox.addView(Ui.text(this, SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 13f, Ui.SUB))
        header.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val statusBadge = if (armed)
            Ui.badge(this, "PERMANENT LOCK 🔒", Ui.CARD_ELEVATED, Ui.GREEN)
        else
            Ui.badge(this, "SETUP MODE ⚙️", Ui.CARD_ELEVATED, Ui.AMBER)
        header.addView(statusBadge)
        col.addView(header, Ui.lp(this))

        // 2. Dynamic Motivation Quote Card
        val quoteCard = Ui.card(this, true)
        val quoteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val quoteText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        quoteText.addView(Ui.text(this, "\"${currentQuote.text}\"", 13f, Ui.LABEL, false))
        quoteText.addView(Ui.text(this, "— ${currentQuote.author}", 11f, Ui.INDIGO_LIGHT, true).apply {
            setPadding(0, d(2), 0, 0)
        })
        quoteRow.addView(quoteText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val refreshBtn = Ui.pill(this, "↻", Ui.CARD, Ui.SUB) {
            currentQuote = Quotes.randomMotivation("hi")
            render()
        }
        quoteRow.addView(refreshBtn)
        quoteCard.addView(quoteRow)
        col.addView(quoteCard, Ui.lp(this, 12))

        // 3. Hero Circular Screen Time Gauge Card
        val hero = Ui.card(this)
        val heroTitle = Ui.text(this, "DAILY SCREEN TIME LIMIT", 11f, Ui.INDIGO_LIGHT, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
        }
        hero.addView(heroTitle)

        val gaugeBox = FrameLayout(this).apply {
            val progressView = CircleProgressView(this@MainActivity)
            progressView.setProgress(usedMin.toFloat(), limitMin.toFloat())
            addView(progressView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

            val centerBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            centerBox.addView(Ui.text(this@MainActivity, "$remainingMin", 36f, Color.WHITE, true))
            centerBox.addView(Ui.text(this@MainActivity, "MIN LEFT", 11f, Ui.SUB, true).apply {
                letterSpacing = 0.12f
            })
            addView(centerBox, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        hero.addView(gaugeBox, LinearLayout.LayoutParams(180 * d(1), 180 * d(1)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = d(10)
            bottomMargin = d(8)
        })

        val heroFooter = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        heroFooter.addView(Ui.text(this, "Used: $usedMin min  •  Limit: $limitMin min", 13f, Ui.SUB))
        hero.addView(heroFooter)
        col.addView(hero, Ui.lp(this, 12))

        // 4. 4-Tile Quick Stats Bar (2x2 Grid)
        val statsRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val statsRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val pDone = if (NamazPrefs.enabled(this)) {
            val dk = Prefs.dayKey()
            (0..4).count { NamazPrefs.done(this, dk, it) }
        } else 5

        val tDone = {
            val dk = Prefs.dayKey()
            Timetable.all(this).count { Timetable.done(this, dk, it.id) }
        }()

        fun statTile(label: String, value: String, accentCol: Int, onClick: () -> Unit): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = Ui.rounded(Ui.CARD_ELEVATED, d(16).toFloat(), Ui.CARD_BORDER, d(1))
                setPadding(d(12), d(14), d(12), d(14))
                isClickable = true
                setOnClickListener { onClick() }
                addView(Ui.text(this@MainActivity, value, 20f, Color.WHITE, true))
                addView(Ui.text(this@MainActivity, label, 11f, accentCol, true).apply { setPadding(0, d(2), 0, 0) })
            }
        }

        val tile1 = statTile("STREAK", "🔥 $streak Days", Ui.AMBER) {
            startActivity(Intent(this, AnalyticsActivity::class.java))
        }
        val tile2 = statTile("DISCIPLINE", "⚡ $score%", Ui.GREEN) {
            startActivity(Intent(this, AnalyticsActivity::class.java))
        }
        val tile3 = statTile("PRAYERS", "🕌 $pDone / 5", Ui.INDIGO_LIGHT) {
            startActivity(Intent(this, NamazActivity::class.java))
        }
        val tile4 = statTile("TASKS", "📋 $tDone / ${Timetable.all(this).size}", Ui.BLUE) {
            startActivity(Intent(this, TimetableActivity::class.java))
        }

        statsRow1.addView(tile1, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = d(4) })
        statsRow1.addView(tile2, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = d(4) })

        statsRow2.addView(tile3, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = d(4) })
        statsRow2.addView(tile4, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = d(4) })

        col.addView(statsRow1, Ui.lp(this, 10))
        col.addView(statsRow2, Ui.lp(this, 8))

        // 5. Featured Modules Hub
        Ui.section(this, col, "Discipline Hub & AI")

        // Voice AI Assistant Highlight Card
        Ui.actionCard(
            this, col,
            "🎙️", "Discipline Voice AI Assistant",
            "Natural voice dialogue for screen time, prayers, task check, and mindset advice",
            Ui.INDIGO
        ) {
            startActivity(Intent(this, VoiceAssistantActivity::class.java))
        }

        // Deep Focus Pomodoro Mode
        Ui.actionCard(
            this, col,
            "⏱️", "Deep Focus & Study Timer",
            "Pomodoro sessions (15-60 min) with ambient rain & white noise audio",
            Ui.GREEN
        ) {
            startActivity(Intent(this, FocusModeActivity::class.java))
        }

        // Prayer Guard
        val nextP = PrayerTimes.next(this)
        val pSub = if (nextP != null)
            "Next: ${PrayerTimes.NAMES[nextP.idx]} at ${SimpleDateFormat("hh:mm a", Locale.US).format(Date(nextP.start))}"
        else "All 5 prayers completed or passed"
        Ui.actionCard(this, col, "🕌", "Prayer Guard", pSub, Ui.BLUE) {
            startActivity(Intent(this, NamazActivity::class.java))
        }

        // Daily Timetable
        val activeTasks = Timetable.active(this)
        val tSub = if (activeTasks.isNotEmpty())
            "Active task: '${activeTasks.first().title}'"
        else "${Timetable.all(this).size} routine tasks configured"
        Ui.actionCard(this, col, "📅", "Daily Timetable", tSub, Ui.PURPLE) {
            startActivity(Intent(this, TimetableActivity::class.java))
        }

        // Analytics & Consistency
        Ui.actionCard(this, col, "📊", "Analytics & Discipline Score", "7-Day performance trends, audit logs, and consistency tips", Ui.AMBER) {
            startActivity(Intent(this, AnalyticsActivity::class.java))
        }

        // 6. Settings & Configurable Rules
        Ui.section(this, col, "Rules & Settings")
        val sc = Ui.cardIn(this, col)
        Ui.row(this, sc, "Daily Screen Time Limit", "$limitMin min", Ui.INDIGO_LIGHT) {
            if (!armed) changeLimitDialog() else toast("Fixed after activation")
        }
        Ui.row(this, sc, "Sleep Mode Schedule", "${TimeUtil.fmtMin(Prefs.sleepStartMin(this))} - ${TimeUtil.fmtMin(Prefs.sleepEndMin(this))}", Ui.INDIGO_LIGHT) {
            if (!armed) changeSleepDialog() else toast("Fixed after activation")
        }
        Ui.row(this, sc, "Passive Voice Guard (Lie Detection)", if (Prefs.bool(this, "voice", true)) "Active ✅" else "Off", Ui.GREEN) {
            if (armed) toast("Cannot be changed after activation")
            else { Prefs.setBool(this, "voice", !Prefs.bool(this, "voice", true)); render() }
        }
        Ui.row(this, sc, "Focus Home as Default Launcher", if (isHome()) "Active ✅" else "Set Default ➔", if (isHome()) Ui.GREEN else Ui.INDIGO_LIGHT) {
            open(Settings.ACTION_HOME_SETTINGS, false)
        }

        // 7. Permissions Checklist
        Ui.section(this, col, "System Permissions")
        val pc = Ui.cardIn(this, col)
        val pm = getSystemService(PowerManager::class.java)
        perm(pc, "Microphone (Voice AI)", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        perm(pc, "Accessibility (Block Engine)", accOn()) {
            open(Settings.ACTION_ACCESSIBILITY_SETTINGS, false)
        }
        perm(pc, "Display Over Other Apps", Settings.canDrawOverlays(this)) {
            open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        }
        perm(pc, "Device Admin (Lock Phone)", Policy.adminActive(this)) {
            try {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed to enforce phone lock"))
            } catch (e: Exception) { toast("Could not open admin settings") }
        }
        perm(pc, "Exact Alarms (Prayer/Routine)", Scheduler.canExact(this)) {
            if (Build.VERSION.SDK_INT >= 31) open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        }
        perm(pc, "Battery Optimization Disabled", pm.isIgnoringBatteryOptimizations(packageName)) {
            open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        }
        perm(pc, "Notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }

        if (!owner) {
            pc.addView(Ui.text(this,
                "ℹ️ Optional Device Owner: For factory-reset-only uninstall protection, run via PC once:\nadb shell dpm set-device-owner com.me.focusguard/com.me.discipline.AdminReceiver",
                12f, Ui.SUB).apply {
                setPadding(0, d(10), 0, d(4))
                setTextIsSelectable(true)
            })
        }

        // 8. Activation Card
        Ui.section(this, col, "Permanent Protection")
        val gc = Ui.cardIn(this, col)
        if (!armed) {
            gc.addView(Ui.gradientButton(this, "ACTIVATE PERMANENTLY", Ui.RED, Color.parseColor("#B91C1C")) {
                confirmActivate()
            }, Ui.lp(this, 4))
            gc.addView(Ui.text(this,
                "⚠️ Before activating: Confirm your daily limit, prayer times, and timetable. Once activated, the guard cannot be turned off, settings cannot be accessed, and rules are permanent.",
                12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(6)) })
        } else {
            gc.addView(Ui.text(this,
                "🔒 Focus Guard is permanently active with zero bypass. No emergency unlocks exist. Stay disciplined and focused on your goals.",
                13f, Ui.GREEN_LIGHT).apply {
                setPadding(0, d(8), 0, d(8))
                setLineSpacing(0f, 1.2f)
            })
        }
    }

    private fun changeLimitDialog() {
        val limits = arrayOf("120 Minutes (2h)", "180 Minutes (3h)", "240 Minutes (4h)", "300 Minutes (5h)")
        val values = intArrayOf(120, 180, 240, 300)
        AlertDialog.Builder(this)
            .setTitle("Set Daily Screen Time Limit")
            .setItems(limits) { _, which ->
                Prefs.setDailyLimitMin(this, values[which])
                render()
            }
            .show()
    }

    private fun changeSleepDialog() {
        val s = Prefs.sleepStartMin(this)
        TimePickerDialog(this, { _, hh, mm ->
            Prefs.setSleepStartMin(this, hh * 60 + mm)
            val e = Prefs.sleepEndMin(this)
            TimePickerDialog(this, { _, ehh, emm ->
                Prefs.setSleepEndMin(this, ehh * 60 + emm)
                render()
            }, e / 60, e % 60, false).show()
        }, s / 60, s % 60, false).show()
    }

    private fun confirmActivate() {
        if (!accOn() || !Policy.adminActive(this)) {
            toast("Allow Accessibility and Device Admin first.")
            return
        }
        val et = EditText(this).apply { hint = "Type LOCK" }
        AlertDialog.Builder(this)
            .setTitle("Activate Focus Guard Permanently")
            .setMessage("Are you 100% sure?\n\n• Daily limit of ${Prefs.dailyLimitMin(this)} min will be fixed\n• Sleep lock (${TimeUtil.fmtMin(Prefs.sleepStartMin(this))} - ${TimeUtil.fmtMin(Prefs.sleepEndMin(this))}) will be fixed\n• Settings will be blocked to prevent disable\n• Missed prayers and routines will lock the phone\n• There is NO emergency unlock\n\nType LOCK below to activate:")
            .setView(et)
            .setPositiveButton("ACTIVATE") { _, _ ->
                if (et.text.toString().trim().uppercase() == "LOCK") {
                    Prefs.activate(this)
                    Hardening.apply(this)
                    Scheduler.rescheduleAll(this)
                    BlockerService.start(this)
                    render()
                    Toast.makeText(this, "Focus Guard activated permanently 🔒", Toast.LENGTH_LONG).show()
                } else {
                    toast("Cancelled. You must type LOCK.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
