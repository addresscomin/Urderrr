package com.me.cleaner

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Guard Cleaner: finds guard-style apps, shows exactly what is blocking their removal,
 * and gives one-tap shortcuts. A normal app cannot silently remove another app's control;
 * Android only allows that for a Device Owner. This tool tells you what to switch off and why.
 */
class CleanerActivity : Activity() {
    private class Item(val pkg: String, val label: String, val admin: Boolean, val acc: Boolean, val owner: Boolean, val home: Boolean)

    private val keys = listOf("discipline", "namaz", "guard")
    private var status = ""
    private var pending: String? = null
    private lateinit var col: LinearLayout

    private val BG = Color.parseColor("#0B0B12")
    private val CARD = Color.parseColor("#16161F")
    private val TXT = Color.parseColor("#F5F5FA")
    private val SUB = Color.parseColor("#8A8A99")
    private val BLUE = Color.parseColor("#8B9BFF")
    private val RED = Color.parseColor("#FF5C6C")
    private val GREEN = Color.parseColor("#4ADE9A")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onResume() { super.onResume(); render() }

    private fun collect(): List<Item> {
        val pm = packageManager
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admins: Set<String> = (dpm.activeAdmins ?: emptyList<ComponentName>()).map { it.packageName }.toSet()
        val accRaw = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val acc: Set<String> = accRaw.split(":").map { it.substringBefore("/") }.filter { it.isNotBlank() }.toSet()
        val homePkg = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        val out = ArrayList<Item>()
        for (ai in pm.getInstalledApplications(0)) {
            val p = ai.packageName
            if (p == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            val label = pm.getApplicationLabel(ai).toString()
            val low = (label + " " + p).lowercase()
            val match = keys.any { low.contains(it) }
            val isAdmin = admins.contains(p)
            val isAcc = acc.contains(p)
            if (!match && !isAdmin && !isAcc) continue
            val isOwner = try { dpm.isDeviceOwnerApp(p) } catch (e: Exception) { false }
            out.add(Item(p, label, isAdmin, isAcc, isOwner, p == homePkg))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    private fun btn(text: String, fg: Int, bg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(fg); gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(14).toFloat() }
            setOnClickListener { onClick() }
        }

    private fun txt(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun lp(top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(56), dp(18), dp(40)) }
        val sv = ScrollView(this).apply { setBackgroundColor(BG); addView(col) }
        setContentView(sv)

        col.addView(txt("Guard Cleaner", 30f, TXT, true))
        col.addView(txt("Finds guard apps, shows what blocks their removal, and helps you remove them.", 14f, SUB), lp(4))

        col.addView(btn("1. Open Device admin apps", Color.BLACK, BLUE) { openAdmin() }, lp(18))
        col.addView(btn("2. Open Accessibility settings", Color.BLACK, BLUE) { startSafe(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(10))

        if (status.isNotBlank()) {
            col.addView(txt(status, 14f, GREEN), lp(16))
        }

        val items = collect()
        col.addView(txt(if (items.isEmpty()) "No guard apps found on this phone." else "Apps found (${items.size})", 16f, TXT, true), lp(22))

        for (app in items) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(20).toFloat() }
            }
            card.addView(txt(app.label, 18f, TXT, true))
            card.addView(txt(app.pkg, 12f, SUB))
            if (app.admin) card.addView(txt("Device admin: ACTIVE (turn it off first)", 13f, RED), lp(6))
            if (app.acc) card.addView(txt("Accessibility service: ON (turn it off)", 13f, RED), lp(2))
            if (app.owner) card.addView(txt("Device Owner: only a factory reset removes this app", 13f, RED), lp(2))
            if (app.home) card.addView(txt("This is your default home screen", 13f, SUB), lp(2))
            if (!app.admin && !app.acc && !app.owner) card.addView(txt("No blocker found. You can uninstall it now.", 13f, GREEN), lp(6))

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val infoBtn = btn("App info", TXT, Color.parseColor("#262633")) {
                startSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
            }
            val delBtn = btn("Uninstall", Color.WHITE, RED) { confirmUninstall(app) }
            row.addView(infoBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
            row.addView(delBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) })
            card.addView(row, lp(12))
            col.addView(card, lp(12))
        }

        col.addView(txt(
            "Tip: if an app keeps coming back after uninstall, restart the phone in Safe Mode and repeat. Safe Mode switches off every third-party blocker.",
            12f, SUB
        ), lp(22))
    }

    private fun startSafe(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { status = "Could not open that screen."; render() }
    }

    private fun openAdmin() {
        try {
            startActivity(Intent().setComponent(ComponentName("com.android.settings", "com.android.settings.DeviceAdminSettings")))
        } catch (e: Exception) {
            startSafe(Intent(Settings.ACTION_SECURITY_SETTINGS))
        }
    }

    private fun confirmUninstall(item: Item) {
        AlertDialog.Builder(this)
            .setTitle("Uninstall " + item.label + "?")
            .setMessage("This removes the app. Make sure it is the one you want to remove.")
            .setPositiveButton("Uninstall") { _, _ ->
                pending = item.pkg
                try {
                    startActivityForResult(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:" + item.pkg)).putExtra(Intent.EXTRA_RETURN_RESULT, true), 7
                    )
                } catch (e: Exception) {
                    status = "Could not open the uninstall screen."; render()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val p = pending ?: return
        pending = null
        val still = try { packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false }
        status = if (!still) {
            "Uninstalled: $p"
        } else {
            val item = collect().firstOrNull { it.pkg == p }
            val why = when {
                item == null -> "Unknown reason."
                item.owner -> "It is the Device Owner, so only a factory reset removes it."
                item.admin -> "Its device admin is still active. Turn it off with button 1, then try again."
                item.acc -> "Its accessibility service is still ON. Turn it off with button 2, then try again."
                else -> "Another policy or app is blocking it. Restart in Safe Mode and try again."
            }
            "Not uninstalled. $why"
        }
        render()
    }
}
