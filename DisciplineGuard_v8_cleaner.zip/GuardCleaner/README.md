# Guard Cleaner 1.0 (com.me.guardcleaner)

A small helper that finds guard-style apps (names containing discipline, namaz or guard, plus any app with an active device admin or accessibility service) and shows exactly what blocks their removal.

It cannot silently remove another app's control: Android only allows that for a Device Owner. It tells you which blocker is on (device admin, accessibility, Device Owner) and gives shortcuts to turn it off and uninstall.

Build: put this project in a zip named DisciplineGuard_v8_cleaner.zip in the repo and run the "Build APK" workflow.
